//
//  Color+Extensions.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/6/25.
//
//  Purpose:
//  - Central place for custom app colors.
//
//  Notes:
//  - Keeps the color palette consistent across all views.
//  - `primaryBlue` pulls from the asset catalog. `neonRed` and `electricBlue`
//    are hard-coded for the optional neon theme.
//

import SwiftUI

extension Color {
    static let primaryBlue = Color("PrimaryBlue")
    static let neonRed = Color(red: 1.0, green: 0.0, blue: 0.4)
    static let electricBlue = Color(red: 0.0, green: 0.7, blue: 1.0)
}
