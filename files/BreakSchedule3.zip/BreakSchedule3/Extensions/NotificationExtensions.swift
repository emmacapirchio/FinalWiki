//
//  NotificationExtensions.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 6/14/25.
//
//  Purpose:
//  - Adds custom notification names used across the app.
//
//  Notes:
//  - Centralizing names here avoids hard-coding strings in multiple files.
//  - `cloudKitSubscriptionNotificationReceived` signals that
//    a CloudKit subscription push has arrived.
//

import Foundation

extension Notification.Name {
    // Posted whenever a CloudKit subscription push is received.
    static let cloudKitSubscriptionNotificationReceived = Notification.Name("cloudKitSubscriptionNotificationReceived")
}
