/*import SwiftUI

struct ContentView: View {
    @State private var name = ""
    @State private var shiftStart: Date = Date()
    @State private var shiftEnd: Date = Date()
    @State private var employees: [Employee] = []
    @State private var schedule: [Schedule] = []
    @State private var editingEmployee: Employee?
    @State private var isShiftStartPickerVisible = false
    @State private var isShiftEndPickerVisible = false

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Text("Break Schedule")
                    .font(.largeTitle)
                    .bold()

                TextField("Name", text: $name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                VStack(alignment: .leading, spacing: 8) {
                    Text("Shift Start")
                        .font(.headline)

                    if isShiftStartPickerVisible {
                        DatePicker(
                            "Select Shift Start",
                            selection: $shiftStart,
                            displayedComponents: [.date, .hourAndMinute]
                        )
                        .datePickerStyle(WheelDatePickerStyle())
                        .labelsHidden()
                        .transition(.scale)
                    } else {
                        Button(action: {
                            isShiftStartPickerVisible.toggle()
                        }) {
                            Text("Tap to Set Shift Start: \(formattedDate(shiftStart))")
                                .foregroundColor(.blue)
                                .padding(.vertical)
                        }
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("Shift End")
                        .font(.headline)

                    if isShiftEndPickerVisible {
                        DatePicker(
                            "Select Shift End",
                            selection: $shiftEnd,
                            displayedComponents: [.date, .hourAndMinute]
                        )
                        .datePickerStyle(WheelDatePickerStyle())
                        .labelsHidden()
                        .transition(.scale)
                    } else {
                        Button(action: {
                            isShiftEndPickerVisible.toggle()
                        }) {
                            Text("Tap to Set Shift End: \(formattedDate(shiftEnd))")
                                .foregroundColor(.blue)
                                .padding(.vertical)
                        }
                    }
                }

                HStack {
                    Button(editingEmployee == nil ? "Add Employee" : "Update Employee") {
                        if let editingEmployee = editingEmployee {
                            updateEmployee(editingEmployee)
                        } else {
                            addEmployee()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    
                    if editingEmployee != nil {
                        Button("Cancel Edit") {
                            cancelEdit()
                        }
                        .buttonStyle(.bordered)
                        .foregroundColor(.red)
                    }

                    Button("Reset All") {
                        resetAll()
                    }
                    .buttonStyle(.bordered)
                    .foregroundColor(.red)
                }

                if schedule.isEmpty {
                    Text("No schedule generated yet.")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    List {
                        ForEach(schedule) { item in
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Name: \(item.name)")
                                    .font(.headline)
                                Text("Shift: \(item.shift)")
                                    .font(.subheadline)
                                Text("First Break: \(item.firstBreak)")
                                    .foregroundColor(.green)
                                Text("Lunch Break: \(item.lunchBreak)")
                                    .foregroundColor(.orange)
                                Text("Second Break: \(item.secondBreak)")
                                    .foregroundColor(.blue)
                                
                                HStack {
                                    Button("Edit") {
                                        editSchedule(item)
                                    }
                                    .buttonStyle(.bordered)
                                    
                                    Button("Delete") {
                                        deleteSchedule(item)
                                    }
                                    .buttonStyle(.bordered)
                                    .foregroundColor(.red)
                                }
                            }
                            .padding()
                        }
                    }
                    .frame(height: 300)
                }
            }
            .padding()
        }
    }

    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEEE, MMM d, h:mm a"
        return formatter.string(from: date)
    }

    private func editSchedule(_ scheduleItem: Schedule) {
        if let employee = employees.first(where: { $0.name == scheduleItem.name }) {
            name = employee.name
            shiftStart = employee.shiftStart
            shiftEnd = employee.shiftEnd
            editingEmployee = employee
        }
    }

    private func deleteSchedule(_ scheduleItem: Schedule) {
        schedule.removeAll { $0.id == scheduleItem.id }
        employees.removeAll { $0.name == scheduleItem.name }
        generateSchedule() // Re-generate the schedule after deletion
    }

    private func addEmployee() {
        guard !name.isEmpty else {
            print("Invalid input: name is empty")
            return
        }
        employees.append(Employee(name: name, shiftStart: shiftStart, shiftEnd: shiftEnd))
        resetFields()
        generateSchedule() // Automatically update schedule
    }

    private func updateEmployee(_ employee: Employee) {
        if let index = employees.firstIndex(where: { $0.id == employee.id }) {
            employees[index] = Employee(id: employee.id, name: name, shiftStart: shiftStart, shiftEnd: shiftEnd)
            resetFields()
            generateSchedule() // Automatically update schedule
        }
    }

    private func cancelEdit() {
        resetFields()
    }

    private func resetFields() {
        name = ""
        shiftStart = Date()
        shiftEnd = Date()
        editingEmployee = nil
    }

    private func resetAll() {
        name = ""
        shiftStart = Date()
        shiftEnd = Date()
        employees = []
        schedule = []
        editingEmployee = nil
        isShiftStartPickerVisible = false
        isShiftEndPickerVisible = false
    }

    private func generateSchedule() {
        guard !employees.isEmpty else {
            schedule = []
            return
        }

        var occupiedBreaks: Set<String> = []

        func findNextAvailableTime(proposedTime: Date) -> Date {
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm"

            var time = proposedTime
            while occupiedBreaks.contains(formatter.string(from: time)) {
                time.addTimeInterval(15 * 60)
            }
            occupiedBreaks.insert(formatter.string(from: time))
            return time
        }

        schedule = employees.map { employee in
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm"

            let shiftDuration = employee.shiftEnd.timeIntervalSince(employee.shiftStart) / 3600
            var firstBreak: Date? = nil
            var lunchBreak: Date? = nil
            var secondBreak: Date? = nil

            if shiftDuration > 4 {
                let proposedFirstBreak = employee.shiftStart.addingTimeInterval(2 * 3600)
                firstBreak = findNextAvailableTime(proposedTime: proposedFirstBreak)
            }

            if shiftDuration > 5.5 {
                let proposedLunchBreak = employee.shiftStart.addingTimeInterval(5 * 3600)
                lunchBreak = findNextAvailableTime(proposedTime: proposedLunchBreak)
            }

            if shiftDuration > 7 {
                let proposedSecondBreak = employee.shiftStart.addingTimeInterval(7 * 3600)
                secondBreak = findNextAvailableTime(proposedTime: proposedSecondBreak)
            }

            return Schedule(
                name: employee.name,
                shift: "\(formatter.string(from: employee.shiftStart)) - \(formatter.string(from: employee.shiftEnd))",
                firstBreak: firstBreak != nil ? formatter.string(from: firstBreak!) : "None",
                lunchBreak: lunchBreak != nil ? formatter.string(from: lunchBreak!) : "None",
                secondBreak: secondBreak != nil ? formatter.string(from: secondBreak!) : "None"
            )
        }
    }
}

// Data Models
struct Employee: Identifiable, Codable {
    let id: UUID
    var name: String
    var shiftStart: Date
    var shiftEnd: Date
    init(id: UUID = UUID(), name: String, shiftStart: Date, shiftEnd: Date) {
        self.id = id
        self.name = name
        self.shiftStart = shiftStart
        self.shiftEnd = shiftEnd
    }
}

struct Schedule: Identifiable, Codable {
    let id = UUID()
    let name: String
    let shift: String
    let firstBreak: String
    let lunchBreak: String
    let secondBreak: String
}
*/
