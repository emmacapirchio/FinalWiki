//
//  BreakSchedule3App.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 11/25/24.
//
//  Purpose:
//  - SwiftUI app entry point. Owns the root view and app-scoped
//    state (ScheduleViewModel) and bridges to AppDelegate for notifications.
//
//  Notes:
//  - We use @UIApplicationDelegateAdaptor to reuse AppDelegate for APNS/CloudKit.
//  - The app shows LoginView until a user is present, then shows SidebarView.
//  - A DEBUG-only local notification is scheduled to verify notification wiring.
//

// Original Code
/*
 import SwiftUI
@main
struct BreakSchedule3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
*/


import SwiftUI
import UserNotifications
import CloudKit

@main
struct BreakSchedule3App: App {
    // Bridges the classic AppDelegate into SwiftUI lifecycle (for APNS + CloudKit push).
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    // App-scoped state container for auth, schedules, swaps, etc.
    // Kept at the top level so all views share one source of truth.
    @StateObject private var viewModel = ScheduleViewModel()

    var body: some Scene {
        WindowGroup {
            Group {
                // If no user is logged in, show login flow; otherwise show the main app.
                if viewModel.loggedInUser == nil {
                    LoginView(viewModel: viewModel)
                        .onAppear { appLog("🟡 Showing LoginView – no user is logged in.") }
                } else {
                    SidebarView(viewModel: viewModel)
                        .onAppear { appLog("🟢 Logged in as \(viewModel.loggedInUser?.username ?? "unknown")") }
                }
            }
            .onAppear {
                // Kick off any initial data needed by the login screen (e.g., user list).
                appLog("📦 App launched – loading users…")
                viewModel.loadUsers()
                
                // DEBUG-only: small local notification to confirm delegate wiring.
                UNUserNotificationCenter.current().getNotificationSettings { settings in
                    if settings.authorizationStatus == .authorized {
                        let content = UNMutableNotificationContent()
                        content.title = "Local Test"
                        content.body  = "Verifying UNUserNotificationCenterDelegate path."
                        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
                        let req = UNNotificationRequest(identifier: "local.debug.boot", content: content, trigger: trigger)
                        UNUserNotificationCenter.current().add(req)
                        appLog("🧪 Scheduled local test notification")
                    } else {
                        appLog("ℹ️ Notifications not authorized yet; skipping local test")
                    }
                }
            }
        }
    }
}
