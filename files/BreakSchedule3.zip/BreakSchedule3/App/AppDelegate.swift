//
//  AppDelegate.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/6/25.
//
//  Purpose:
//  - Wire up notifications (APNS + CloudKit) and expose simple
//    app-wide events that SwiftUI can observe.
//
//  Notes:
//  - We translate CloudKit pushes into NotificationCenter events.
//  - Logs are for understanding app flow; no sensitive data is printed.
//

import UIKit
import CloudKit
import UserNotifications

// MARK: - Global Logger
// Lightweight log helper that shows where a message came from.
func appLog(_ message: String,
            file: String = #file,
            function: String = #function,
            line: Int = #line) {
    let filename = (file as NSString).lastPathComponent
    let formatted = "[\(filename):\(line)] \(function) – \(message)"
    
    // Xcode console
    print(formatted)
    
    // On-screen logger
    DebugLogger.shared.add(formatted)
}

class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    // MARK: - App lifecycle
    // Sets up notification delegate and registers for pushes (if already allowed).
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        
        // APNS - Apple Push Notification System
        // If the user has already granted permission, this registers for APNS.
        NotificationHelper.registerIfAuthorized()
        
        // Removed for production
        // AuthManager.shared.printHashedPassword("password")
        
        appLog("AppDelegate finished launching.")
        return true
    }
    
    // MARK: - APNS Registration
    func application(_ application: UIApplication,
                     didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        appLog("Registered for remote notifications.")
    }
    
    func application(_ application: UIApplication,
                     didFailToRegisterForRemoteNotificationsWithError error: Error) {
        appLog("Failed to register for notifications: \(error.localizedDescription)")
    }
    
    // MARK: - CloudKit push handling
    // Receives CloudKit subscription pushes and broadcast simple app events.
    func application(_ application: UIApplication,
                     didReceiveRemoteNotification userInfo: [AnyHashable: Any],
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        appLog("Received CloudKit push: \(userInfo)")
        
        if let ck = CKNotification(fromRemoteNotificationDictionary: userInfo),
           let subID = ck.subscriptionID {
            
            if subID.hasPrefix("incoming-messages-") {
                appLog("Incoming message push detected.")
                NotificationCenter.default.post(name: .incomingMessagePush, object: nil)
            } else if subID.hasPrefix("swap-status-") {
                appLog("Swap status push detected.")
                NotificationCenter.default.post(name: .swapStatusPush, object: nil)
            } else {
                appLog("Generic CloudKit push detected.")
                NotificationCenter.default.post(name: .cloudKitSubscriptionNotificationReceived, object: nil)
            }
        } else {
            // Not a CK payload (or malformed) — still nudge listeners to refresh if needed.
            appLog("Push payload did not contain CKNotification.")
            NotificationCenter.default.post(name: .cloudKitSubscriptionNotificationReceived, object: nil)
        }
        
        completionHandler(.newData)
    }
    
    // MARK: - Foreground notifications
    // Show banners even when the app is open (keeps behavior consistent).
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let info = notification.request.content.userInfo
        appLog("willPresent id=\(notification.request.identifier) userInfo=\(info)")
        completionHandler([.banner, .list, .sound, .badge])
    }
    
    // MARK: - Notification taps
    // User tapped a delivered notification.
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let info = response.notification.request.content.userInfo
        appLog("didReceive tap id=\(response.notification.request.identifier) userInfo=\(info)")
        completionHandler()
    }
}

// MARK: - Notification Names
extension Notification.Name {
    // Generic "CloudKit changed something" event (use when you just need a refresh).
    static let cloudKitSubscriptionNotificationReceived = Notification.Name("cloudKitSubscriptionNotificationReceived")
    // New inbound message saved to CloudKit.
    static let incomingMessagePush = Notification.Name("incomingMessagePush")
    // Shift swap status changed (approved/denied/etc.).
    static let swapStatusPush = Notification.Name("swapStatusPush")
}
