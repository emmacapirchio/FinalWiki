//
//  ShiftEditorView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 4/3/25.
//
//  Purpose:
//  - Used inside scheduling forms to edit a single employee’s
//    shift details. Allows setting start/end times, selecting
//    department-specific notes, and adding goals. Supports an optional
//    neon theme for visual emphasis.
//

import SwiftUI

// Extra color used when neon theme is enabled
extension Color {
    static let testElectricBlue = Color(red: 0.0, green: 0.7, blue: 1.0)
}

struct ShiftEditorView: View {
    @Binding var employeeShift: EmployeeShift
    var useNeonTheme: Bool
    var viewModel: ScheduleViewModel

    var body: some View {
        Section(header:
            Text(employeeShift.name)
                // Use neon highlight if enabled, otherwise default text color
                .foregroundColor(useNeonTheme ? .testElectricBlue : .primary)
                .font(.headline)
        ) {
            // Shift start time picker
            DatePicker("Shift Start", selection: Binding(
                get: { employeeShift.shiftStart ?? Date() },
                set: { newValue in
                    employeeShift.shiftStart = newValue
                    viewModel.setShiftStart(for: employeeShift, start: newValue)
                }
            ), displayedComponents: [.date, .hourAndMinute])

            // Shift end time picker
            DatePicker("Shift End", selection: Binding(
                get: { employeeShift.shiftEnd ?? Date().addingTimeInterval(8 * 3600) },
                set: { newValue in
                    employeeShift.shiftEnd = newValue
                    viewModel.setShiftEnd(for: employeeShift, end: newValue)
                }
            ), displayedComponents: [.date, .hourAndMinute])

            // Department-specific note options
            let options = DepartmentNotes.notes(for: employeeShift.department)

            // Picker for selecting notes
            Picker("Notes", selection: Binding(
                get: { employeeShift.notes },
                set: { newValue in
                    employeeShift.notes = newValue
                    viewModel.updateNotes(for: employeeShift, notes: newValue)
                }
            )) {
                ForEach(options, id: \.self) { note in
                    Text(note).tag(note)
                }
            }
            .pickerStyle(SegmentedPickerStyle())

            // Text field for entering shift-specific goals
            TextField("Goals", text: Binding(
                get: { employeeShift.goals },
                set: { newValue in
                    employeeShift.goals = newValue
                    viewModel.updateGoals(for: employeeShift, goals: newValue)
                }
            ))
            .textFieldStyle(RoundedBorderTextFieldStyle())
        }
    }
}



