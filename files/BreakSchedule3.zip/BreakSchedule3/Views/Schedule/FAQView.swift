//
//  FAQItem.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 5/15/25.
//
//  Purpose:
//  - Provides a simple FAQ (Frequently Asked Questions) screen
//    where users can search common questions and tap to expand answers.
//    Uses a local array of FAQItem structs; no CloudKit or network call required.
//

import SwiftUI

// Model representing each FAQ entry
struct FAQItem: Identifiable {
    let id = UUID()
    let question: String
    let answer: String
}

struct FAQView: View {
    @State private var searchText = ""
    @State private var expandedItem: UUID?
    
    // Hard-coded list of FAQs for quick reference
    let faqItems = [
        FAQItem(question: "How do I request a shift swap?", answer: "Go to your schedule, select the shift, and tap the swap button."),
        FAQItem(question: "How do I view my schedule?", answer: "Navigate to the 'My Schedule' tab from the main menu."),
        FAQItem(question: "What should I do if I can't log in?", answer: "Ensure your credentials are correct or contact your administrator."),
        FAQItem(question: "How do I edit a shift?", answer: "Go to the shift details and select 'Edit' from the options menu.")
    ]
    
    // Filter FAQ list based on search text
    var filteredItems: [FAQItem] {
        if searchText.isEmpty {
            return faqItems
        } else {
            return faqItems.filter { $0.question.lowercased().contains(searchText.lowercased()) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                // Search field to quickly find relevant questions
                TextField("Search FAQs...", text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                // Expandable list of questions/answers
                List {
                    ForEach(filteredItems) { item in
                        DisclosureGroup(
                            isExpanded: .constant(expandedItem == item.id),
                            content: {
                                Text(item.answer)
                                    .padding()
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(8)
                            },
                            label: {
                                Text(item.question)
                                    .font(.headline)
                                    .foregroundColor(.blue)
                            }
                        )
                        .onTapGesture {
                            // Toggle which FAQ item is expanded
                            expandedItem = (expandedItem == item.id) ? nil : item.id
                        }
                    }
                }
            }
            .navigationTitle("FAQs")
        }
    }
}
