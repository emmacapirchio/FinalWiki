//
//  PastSchedulesView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/1/24.
//
//  Purpose:
//  - Displays all previously generated schedules for the logged-in user.
//    Store Directors can delete past schedules directly from this view.
//    Data is fetched from CloudKit and flattened for easy listing.
//

// Original
/*import SwiftUI

struct PastSchedulesView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var showDeleteAlert = false
    @State private var scheduleToDeleteIndex: Int? = nil

    var body: some View {
        VStack {
            if viewModel.loggedInUser == nil {
                Text("Please log in to view past schedules.")
                    .font(.headline)
                    .padding()
            } else if viewModel.pastSchedules.isEmpty {
                Text("No past schedules found.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List {
                    ForEach(viewModel.pastSchedules.indices, id: \.self) { index in
                        Section(header: HStack {
                            Text("Schedule \(index + 1)")
                            Spacer()
                            Button(role: .destructive) {
                                scheduleToDeleteIndex = index
                                showDeleteAlert = true
                            } label: {
                                Image(systemName: "trash")
                            }
                            .buttonStyle(.borderless) // To avoid row-level button triggering
                        }) {
                            ForEach(viewModel.pastSchedules[index]) { schedule in
                                VStack(alignment: .leading) {
                                    Text("Name: \(schedule.name)")
                                    Text("Shift: \(schedule.shift)")
                                    Text("First Break: \(schedule.firstBreak)")
                                    Text("Lunch Break: \(schedule.lunchBreak)")
                                    Text("Second Break: \(schedule.secondBreak)")
                                }
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Past Schedules")
        .alert("Delete Schedule", isPresented: $showDeleteAlert) {
            Button("Delete", role: .destructive) {
                if let index = scheduleToDeleteIndex {
                    viewModel.deleteSchedule(at: index)
                    scheduleToDeleteIndex = nil
                }
            }
            Button("Cancel", role: .cancel) {
                scheduleToDeleteIndex = nil
            }
        } message: {
            Text("Are you sure you want to delete this schedule?")
        }
    }
}*/

import SwiftUI

struct PastSchedulesView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var showDeleteAlert = false
    @State private var scheduleToDelete: Schedule?

    var body: some View {
        VStack {
            Text("Past Schedules")
                .font(.largeTitle)
                .foregroundColor(Color("PrimaryBlue"))
                .padding()

            // Empty-state message
            if viewModel.pastSchedules.flatMap({ $0 }).isEmpty {
                Text("No past schedules found.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding()
            } else {
                // Show every past schedule as a single flat list
                List(viewModel.pastSchedules.flatMap { $0 }, id: \.id) { schedule in
                    HStack {
                        // Schedule details
                        VStack(alignment: .leading) {
                            Text("Name: \(schedule.name)").font(.headline)
                            Text("Shift: \(schedule.shift)")
                            Text("First Break: \(schedule.firstBreak)")
                            Text("Lunch Break: \(schedule.lunchBreak)")
                            Text("Second Break: \(schedule.secondBreak)")
                        }
                        Spacer()
                        // Store Directors can delete individual past schedules
                        if viewModel.loggedInUser?.role == .storeDirector {
                            Button {
                                scheduleToDelete = schedule
                                showDeleteAlert = true
                            } label: {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                                    .padding(.horizontal)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical, 4)
                }


            }
        }
        // Confirmation alert for deleting a past schedule
        .alert(isPresented: $showDeleteAlert) {
            Alert(
                title: Text("Delete Schedule"),
                message: Text("Are you sure you want to delete this past schedule?"),
                primaryButton: .destructive(Text("Delete")) {
                    if let schedule = scheduleToDelete {
                        viewModel.deletePastSchedule(schedule: schedule)
                    }
                },
                secondaryButton: .cancel()
            )
        }
        // Light blue background to match app theme
        .background(Color.primaryBlue.opacity(0.1).edgesIgnoringSafeArea(.all))
        // Fetch data whenever the view appears
        .onAppear {
            viewModel.fetchPastSchedules()
        }
    }
}
