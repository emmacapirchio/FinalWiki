//
//  MyBreakScheduleView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/6/25.
//
//  Purpose:
//  - Shows the logged-in team member’s upcoming shifts and allows them
//    to propose a shift swap. Fetches shifts from CloudKit and presents each as
//    a tappable card with shift times, notes, and goals. Opens a swap form when
//    a shift is selected.
//

import SwiftUI
import Foundation
import CloudKit

struct MyBreakScheduleView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var employeeShifts: [EmployeeShift] = []
    @State private var selectedShiftForSwap: EmployeeShift?
    @State private var showSwapSheet = false
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        ZStack {
            Color.primaryBlue.opacity(0.1).edgesIgnoringSafeArea(.all)

            VStack {
                Text("My Shifts")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(colorScheme == .dark ? .white : .primaryBlue)
                    .padding()

                // Show message if there are no shifts
                if employeeShifts.isEmpty {
                    Text("No shifts assigned yet.")
                        .font(.subheadline)
                        .foregroundColor(colorScheme == .dark ? .white : .gray)
                        .padding()
                } else {
                    // Scrollable list of the user’s shifts
                    ScrollView {
                        VStack(spacing: 12) {
                            ForEach(employeeShifts, id: \.id) { shift in
                                ShiftCard(
                                    shift: shift,
                                    userRole: viewModel.loggedInUser?.role ?? .tm,
                                    onProposeSwap: {
                                        // Store the selected shift and trigger sheet presentation
                                        DispatchQueue.main.async {
                                            print("Setting selectedShiftForSwap to: \(shift.id)")
                                            selectedShiftForSwap = shift
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                                                print("Showing swap sheet")
                                                showSwapSheet = true
                                            }
                                        }
                                    }
                                )
                            }
                        }
                        .padding()
                    }
                }
            }
        }
        .onAppear {
            // Fetch this user’s shifts when the view appears
            guard let user = viewModel.loggedInUser else {
                print("No logged-in user!")
                return
            }
            print("Logged-in user: \(user.username) – fetching by employeeName")

            CloudKitManager.shared.fetchEmployeeShifts(forUsername: user.username) { result in
                switch result {
                case .success(let shifts):
                    print("Fetched \(shifts.count) shifts for \(user.username)")
                    self.employeeShifts = shifts
                case .failure(let error):
                    print("Failed to load shifts: \(error.localizedDescription)")
                }
            }
        }
        // Present swap request sheet when a shift is chosen
        .sheet(item: $selectedShiftForSwap) { shift in
            SwapRequestFormView(preselectedMyShift: shift)
                .environmentObject(viewModel)
        }
    }

    // Reload shifts on demand
    private func reloadMyShifts() {
        guard let user = viewModel.loggedInUser else { return }
        CloudKitManager.shared.fetchEmployeeShifts(forUsername: user.username) { result in
            if case .success(let shifts) = result {
                self.employeeShifts = shifts
            }
        }
    }
}

// MARK: - ShiftCard
// Visual card showing details for a single shift, with a button to propose a swap.
struct ShiftCard: View {
    let shift: EmployeeShift
    let userRole: EmployeeRole
    let onProposeSwap: () -> Void
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Shift: \(formatted(shift.shiftStart)) → \(formatted(shift.shiftEnd))")
                .font(.headline)
                .foregroundColor(colorScheme == .dark ? .white : .primaryBlue)

            Text("Notes: \(shift.notes)")
            Text("Goals: \(shift.goals)")

            if userRole == .tm {
                Button("Propose Swap") { onProposeSwap() }
                    .foregroundColor(.blue)
                    .padding(.top)
            }
        }
        .padding()
        .background(colorScheme == .dark ? Color.black : Color.white)
        .cornerRadius(12)
        .shadow(radius: 5)
    }

    // Format optional dates for display
    func formatted(_ date: Date?) -> String {
        guard let date = date else { return "N/A" }
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
