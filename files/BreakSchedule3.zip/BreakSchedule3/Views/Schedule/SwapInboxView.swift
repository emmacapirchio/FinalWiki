//
//  SwapInboxView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 4/23/25.
//
//  Purpose:
//  - Shows team members (TMs) the swap requests that involve their
//    scheduled shifts. Allows them to accept or decline requests that have
//    already been approved by a manager and are waiting on their response.
//


import SwiftUI

struct SwapInboxView: View {
    // Handles fetching and responding to shift swap requests
    @StateObject private var swapViewModel = ShiftSwapViewModel()
    // Accesses the logged-in user and overall schedule state
    @EnvironmentObject var scheduleViewModel: ScheduleViewModel

    var body: some View {
        NavigationView {
            VStack {
                // Empty state when there are no swap requests
                if swapViewModel.shiftSwapRequests.isEmpty {
                    Text("No swap requests available.")
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    // List of swap requests for this user
                    List(swapViewModel.shiftSwapRequests, id: \.id.recordName) { request in
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Requested by: \(request.proposerEmployeeName)")
                                .font(.headline)
                            
                            // Show current status
                            Text("Status: \(request.status.capitalized)")
                                .foregroundColor(request.status == "PendingApproval" ? .orange : .gray)

                            Text("Created: \(request.timestamp.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption)

                            // If the request is ready for this user's decision, show Accept/Decline buttons
                            if request.status == "PendingAcceptance" {
                                HStack {
                                    Button("Accept") {
                                        if let user = scheduleViewModel.loggedInUser {
                                            swapViewModel.respondToSwapRequest(request, accept: true, currentUserId: user.id)
                                        }
                                    }
                                    .foregroundColor(.green)

                                    Button("Decline") {
                                        if let user = scheduleViewModel.loggedInUser {
                                            swapViewModel.respondToSwapRequest(request, accept: false, currentUserId: user.id)
                                        }
                                    }
                                    .foregroundColor(.red)
                                }
                                .padding(.top, 4)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .navigationTitle("Shift Swap Requests")
            .onAppear {
                // Load swap requests once a user is confirmed
                if let user = scheduleViewModel.loggedInUser {
                    swapViewModel.loadSwapRequests()

                }
            }
            // Alert shown after successful swap
            .alert(isPresented: $swapViewModel.showSwapSuccessAlert) {
                Alert(
                    title: Text("Success"),
                    message: Text(swapViewModel.swapSuccessMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }
}
