//
//  ShiftInputView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/1/24.
//
//  Purpose:
//  - Displays a list of ShiftEditorView rows so a manager can
//    set start/end times, notes, and goals for each selected employee.
//    Includes a “Create Schedule” toolbar button to save all edits.
//

import SwiftUI

// Extra color used for neon theme
extension Color {
    static let neonRed = Color(red: 1.0, green: 0.0, blue: 0.4)
}

struct ShiftInputView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        Form {
            // Loop over each selected employee and show an editable shift section
            ForEach(Array(viewModel.selectedEmployees.indices), id: \.self) { index in
                ShiftEditorView(
                    employeeShift: $viewModel.selectedEmployees[index],
                    useNeonTheme: viewModel.useNeonTheme,
                    viewModel: viewModel
                )
            }
            .toolbar {
                // Toolbar button to create and save the schedule
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Create Schedule") {
                        viewModel.generateAndSaveSchedule()
                        presentationMode.wrappedValue.dismiss()
                    }
                    .padding(8)
                    .background(viewModel.useNeonTheme ? Color.neonRed : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }
            }

        }

    }
}


// MARK: - ViewModel Extensions
// Helper methods to update individual shift fields inside the view model
extension ScheduleViewModel {
    func setShiftStart(for employeeShift: EmployeeShift, start: Date) {
        if let index = shifts.firstIndex(where: { $0.id == employeeShift.id }) {
            shifts[index].shiftStart = start
        }
    }
    func setShiftEnd(for employeeShift: EmployeeShift, end: Date) {
        if let index = shifts.firstIndex(where: { $0.id == employeeShift.id }) {
            shifts[index].shiftEnd = end
        }
    }

    
    func updateNotes(for employeeShift: EmployeeShift, notes: String) {
        if let index = shifts.firstIndex(where: { $0.id == employeeShift.id }) {
            shifts[index].notes = notes
        }
    }
    
    func updateGoals(for employeeShift: EmployeeShift, goals: String) {
        if let index = shifts.firstIndex(where: { $0.id == employeeShift.id }) {
            shifts[index].goals = goals
        }
    }
}

