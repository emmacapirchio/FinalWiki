//
//  SchedulePDFExportView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 5/26/25.
//
//  Purpose:
//  - Allows a manager to pick a date, generate a PDF of that day's schedule,
//    and immediately share or save it. Uses CloudKit to fetch the correct shifts
//    and the app’s built-in PDF generator to create the document.
//

import SwiftUI
import UIKit

struct SchedulePDFExportView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var selectedDate = Date()
    @State private var pdfURL: URL?
    @State private var showShareSheet = false

    var body: some View {
        VStack(spacing: 20) {
            Text("Export Schedule PDF")
                .font(.title2)

            // Date picker to choose which day’s schedule to export
            DatePicker("Select a date", selection: $selectedDate, displayedComponents: .date)

            // Button to fetch shifts and generate the PDF
            Button("Generate PDF") {
                viewModel.fetchShiftsForDate(selectedDate) { shifts in
                    if let url = viewModel.generateSchedulePDF(for: selectedDate, shifts: shifts) {
                        self.pdfURL = url
                        self.showShareSheet = true // Opens the iOS share sheet
                        print("PDF saved to: \(url)")
                    } else {
                        print("Could not generate PDF")
                    }
                }
            }

            // Quick confirmation label showing saved PDF file name
            if let url = pdfURL {
                Text("PDF saved: \(url.lastPathComponent)")
                    .font(.caption)
                    .foregroundColor(.green)
            }
        }
        .padding()
        // Present system share sheet (AirDrop, email, etc.) for the generated PDF
        .sheet(isPresented: $showShareSheet) {
            if let pdfURL = pdfURL {
                ShareSheet(activityItems: [pdfURL])
            }
        }
    }
}

// MARK: - Native iOS share sheet wrapper
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any] // Items to share
    let applicationActivities: [UIActivity]? = nil

    func makeUIViewController(context: Context) -> UIActivityViewController {
        return UIActivityViewController(
            activityItems: activityItems,
            applicationActivities: applicationActivities
        )
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

