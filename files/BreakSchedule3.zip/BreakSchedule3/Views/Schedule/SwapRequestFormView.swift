//
//  SwapRequestFormView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 4/24/25.
//
//  Purpose:
//  - Allows a team member (TM) to propose a shift swap by selecting
//    one of their own shifts and a coworker’s shift. Submits the swap request
//    to CloudKit for manager approval and coworker acceptance.
//

import SwiftUI
import CloudKit

struct SwapRequestFormView: View {
    var preselectedMyShift: EmployeeShift? = nil
    // Access to the logged-in user and scheduling data
    @EnvironmentObject var scheduleViewModel: ScheduleViewModel
    // Manages form state and CloudKit operations
    @StateObject private var viewModel = SwapRequestFormViewModel()

    var body: some View {
        Form {
            // MARK: Your shift
            Section(header: Text("Your Shift")) {
                // Picker for the current user's own shifts
                Picker("Select Your Shift", selection: $viewModel.selectedMyShiftId) {
                    ForEach(viewModel.myShifts, id: \.id) { shift in
                        Text(shiftDisplay(shift))
                            .tag(shift.id as CKRecord.ID?)
                    }
                }
                .onChange(of: viewModel.selectedMyShiftId) { newValue in
                    // Debugging logs to trace selection changes
                    print("Picker changed: selectedMyShiftId = \(String(describing: newValue))")
                    print("Current shift options: \(viewModel.myShifts.map { $0.id })")
                }
            }

            // MARK: Coworker
            Section(header: Text("Coworker")) {
                // Picker for selecting a coworker to swap with
                Picker("Select Coworker", selection: $viewModel.selectedCoworkerId) {
                    if viewModel.coworkers.isEmpty {
                        Text("No coworkers available").tag(CKRecord.ID?.none) // <-- correct placeholder tag type
                    } else {
                        ForEach(viewModel.coworkers, id: \.id) { employee in
                            Text(employee.name)
                                .tag(employee.id as CKRecord.ID?) // <-- explicit tag type
                        }
                    }
                }
                .onAppear {
                    // Auto-select the first coworker if none chosen
                    if viewModel.selectedCoworkerId == nil, let first = viewModel.coworkers.first {
                        viewModel.selectedCoworkerId = first.id
                        print("Auto-selected coworker: \(first.name) [\(first.id)]")
                    }
                }
                .onChange(of: viewModel.selectedCoworkerId) { newId in
                    // When coworker changes, fetch their shifts
                    guard
                        let coworkerId = newId,
                        let coworker = viewModel.coworkers.first(where: { $0.id == coworkerId })
                    else { return }

                    print("Selected coworker: \(coworker.name) [\(coworkerId)]")

                    viewModel.coworkerShifts = []
                    viewModel.selectedCoworkerShiftId = nil

                    // Fetch coworker shifts by username (matches BreakSchedule.employeeName)
                    CloudKitManager.shared.fetchEmployeeShifts(forUsername: coworker.name) { result in
                        DispatchQueue.main.async {
                            switch result {
                            case .success(let shifts):
                                print("Loaded \(shifts.count) shifts for coworker \(coworker.name)")
                                viewModel.coworkerShifts = shifts
                                if let first = shifts.first {
                                    viewModel.selectedCoworkerShiftId = first.id
                                    print("Auto-selected coworker shift: \(first.id)")
                                }
                            case .failure(let error):
                                print("Failed to load coworker shifts: \(error.localizedDescription)")
                                viewModel.coworkerShifts = []
                            }
                        }
                    }
                }
            }

            // Button to submit the swap request
            Button("Submit Request for Approval") {
                viewModel.sendRequest(from: scheduleViewModel.loggedInUser)
            }
            // Disable button until required selections are made
            .disabled(viewModel.selectedMyShiftId == nil || viewModel.selectedCoworkerId == nil)
        }
        .navigationTitle("Propose Swap")
        .onAppear {
            // Load user and optionally preselect their shift
            if let user = scheduleViewModel.loggedInUser {
                print("Logged-in user in SwapRequestFormView: \(user.username) [\(user.id)]")
                if let preselected = preselectedMyShift {
                    print("Preselected shift passed in: \(preselected.id)")
                    viewModel.loadData(for: user, preselecting: preselected.id)
                } else {
                    print("No preselected shift provided.")
                    viewModel.loadData(for: user)
                }
            } else {
                print("No user found in scheduleViewModel.")
            }
        }
        // Success alert when request is sent
        .alert(isPresented: $viewModel.showAlert) {
            Alert(
                title: Text("Success"),
                message: Text(viewModel.alertMessage),
                dismissButton: .default(Text("OK"))
            )
        }
    }

    // Helper to format a shift’s start and end time
    private func shiftDisplay(_ shift: EmployeeShift) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        guard let start = shift.shiftStart, let end = shift.shiftEnd else { return "Incomplete Shift" }
        return "\(formatter.string(from: start)) -> \(formatter.string(from: end))"
    }
}
