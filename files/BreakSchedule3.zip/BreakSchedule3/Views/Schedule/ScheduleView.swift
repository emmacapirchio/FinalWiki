//
//  ScheduleView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/1/24.
//
//  Purpose:
//  - Displays the currently generated break schedule,
//    lets a manager generate and view new schedules for selected employees,
//    and provides quick actions like clearing or emailing schedules.
//

import SwiftUI

struct ScheduleView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var showEmail = false
    @State private var pdfData: Data?
    @State private var showGeneratedSchedulesView = false
    @State private var generatedSchedules: [Schedule] = []

    var body: some View {
        NavigationView {
            VStack {
                // Display current schedule or a placeholder if empty
                if viewModel.schedule.isEmpty {
                    Text("No schedule available.")
                        .font(.headline)
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    List(viewModel.schedule, id: \.id) { item in
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Name: \(item.name)").font(.headline)
                            Text("Shift: \(item.shift)").font(.subheadline)
                            Text("First Break: \(item.firstBreak)").foregroundColor(.green)
                            Text("Lunch Break: \(item.lunchBreak)").foregroundColor(.orange)
                            Text("Second Break: \(item.secondBreak)").foregroundColor(.blue)
                            Text("Goals: \(item.goals.isEmpty ? "Not applicable" : "\(item.goals) units")")
                                .foregroundColor(item.goals.isEmpty ? .gray : .purple)
                        }
                    }
                }

                // Action buttons: generate schedules and clear current schedule
                HStack {
                    Button("Generate and Show Schedules") {
                        if viewModel.selectedEmployees.isEmpty {
                            // Ensure employees are selected before generating a schedule
                            alertMessage = "Please select employees before generating a schedule."
                            showAlert = true
                        } else {
                            // Generate and immediately display new schedules
                            viewModel.generateAndSaveSchedule()
                            generatedSchedules = viewModel.schedule
                            showGeneratedSchedulesView = true
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .padding()

                    Button("Clear All") {
                        // Remove all schedules from the current session
                        viewModel.clearSchedule()
                    }
                    .buttonStyle(.borderedProminent)
                    .padding()

                    // Currently disabled email feature
                    /*Button("Email Schedule as PDF") {
                        pdfData = viewModel.generatePDF(for: viewModel.schedule)
                        if let _ = pdfData {
                            showEmail = true
                        } else {
                            alertMessage = "Failed to generate PDF."
                            showAlert = true
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .padding()*/
                }
            }
            .navigationTitle("Break Schedule")
            // Navigate to GeneratedSchedulesView when a schedule is created
            .background(
                NavigationLink(
                    destination: GeneratedSchedulesView(viewModel: viewModel, generatedSchedules: generatedSchedules),
                    isActive: $showGeneratedSchedulesView,
                    label: { EmptyView() }
                )
            )
            // Alert for missing selections or PDF errors
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Notice"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }
}
