//
//  SwapApprovalView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 5/16/25.
//
//  Purpose:
//  - Lets store directors, ETLs, or TLs review and act on pending shift swap
//    requests. Each request can be approved (which exchanges ownership of the shifts
//    and refreshes the schedule) or denied.
//

import SwiftUI

struct SwapApprovalView: View {
    // View model that loads and manages pending swap requests
    @StateObject private var viewModel = SwapApprovalViewModel()
    // Provides access to the main schedule data and logged-in user
    @EnvironmentObject var scheduleViewModel: ScheduleViewModel
    @State private var showApproveError = false
    @State private var approveErrorMessage = ""

    var body: some View {
        NavigationView {
            // List of all pending swap requests
            List(viewModel.pendingRequests) { request in
                VStack(alignment: .leading, spacing: 8) {
                    Text("Proposed Swap:")
                        .font(.headline)
                    Text("From: \(request.proposerEmployeeName)")
                    Text("To: \(request.requestedEmployeeName)")
                    Text("Status: \(request.statusEnumDisplay)")
                    Text("Proposed at: \(formattedDate(request.timestamp))")
                    
                    let user = scheduleViewModel.loggedInUser
                    let canApprove = user.map { request.canApprove(currentUserId: $0.id, currentUserRole: $0.role) } ?? false
                    let isPending = request.isPending

                    HStack {
                        // Approve button: swaps shifts and removes the request from the list
                        Button("Approve") {
                            guard let username = scheduleViewModel.loggedInUser?.username else { return }

                            CloudKitManager.shared.approveSwapAndExchangeOwnership(
                                swapRequestID: request.id,
                                approverUsername: username
                            ) { result in
                                switch result {
                                case .success:
                                    print("Swap approved and shifts exchanged.")

                                    // Optimistically remove from pending list
                                    if let idx = viewModel.pendingRequests.firstIndex(where: { $0.id == request.id }) {
                                        viewModel.pendingRequests.remove(at: idx)
                                    }

                                    // Refresh schedules so MyBreakSchedule/other views reflect the change
                                    scheduleViewModel.fetchCurrentSchedules()

                                case .failure(let error):
                                    approveErrorMessage = CloudKitManager.prettyError(error)
                                    showApproveError = true
                                    print("Approval failed: \(error.localizedDescription)")
                                }
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(!canApprove)

                        // Deny button: marks request as denied without swapping
                        Button("Deny") {
                            if let username = user?.username {
                                viewModel.denySwap(request, approvedBy: username)
                            }
                        }
                        .buttonStyle(.bordered)
                        .disabled(!isPending)
                    }
                }
                .padding(.vertical, 8)
            }
            .listStyle(.insetGrouped)
            // Pull-to-refresh to reload pending requests
            .refreshable {
                viewModel.fetchPendingSwapRequests()
            }
            .navigationTitle("Pending Swap Requests")
            .onAppear {
                // Initial fetch when the view first appears
                viewModel.fetchPendingSwapRequests()
            }
            .alert("Approve failed", isPresented: $showApproveError) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(approveErrorMessage)
            }
        }
    }

    // Formats a Date into a short, user-friendly string
    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

private extension ShiftSwapRequest {
    var statusEnumDisplay: String {
        switch statusEnum {
        case .pending:   return "Pending"
        case .accepted:  return "Accepted"
        case .declined:  return "Declined"
        case .cancelled: return "Cancelled"
        case .approved:  return "Approved"
        }
    }
}
