//
//  MessagesView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 6/14/25.
//
//  Purpose:
//  - A lightweight chat screen for sending and viewing messages
//    between the logged-in user and a selected chat partner. Uses the
//    MessagesViewModel to fetch and send CloudKit-based messages.
//

import SwiftUI

struct MessagesView: View {
    @StateObject private var viewModel = MessagesViewModel()

    let currentUser: User
    let chatPartner: User

    var body: some View {
        VStack {
            // Scrollable list of messages
            ScrollViewReader { scrollView in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(viewModel.messages) { message in
                            HStack {
                                if message.sender.id == currentUser.id {
                                    // Outgoing message bubble, right aligned
                                    Spacer()
                                    Text(message.content)
                                        .padding()
                                        .background(Color.blue.opacity(0.2))
                                        .cornerRadius(10)
                                } else {
                                    // Incoming message bubble, left aligned
                                    Text(message.content)
                                        .padding()
                                        .background(Color.gray.opacity(0.2))
                                        .cornerRadius(10)
                                    Spacer()
                                }
                            }
                            .id(message.id) // Used for automatic scrolling
                        }
                    }
                    .padding()
                }
                .onChange(of: viewModel.messages.count) { _ in
                    // Scroll to the newest message whenever one is added
                    if let last = viewModel.messages.last {
                        scrollView.scrollTo(last.id, anchor: .bottom)
                    }
                }
            }

            // Input field and send button
            HStack {
                TextField("Enter message", text: $viewModel.messageText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                Button("Send") {
                    viewModel.sendMessage(from: currentUser, to: chatPartner)
                }
                .disabled(viewModel.messageText.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            .padding()
        }
        // Show chat partner name in the navigation bar
        .navigationTitle(chatPartner.username)
        .onAppear {
            // Load the full conversation on view load
            viewModel.loadMessages(between: currentUser, and: chatPartner)
        }
    }
}
