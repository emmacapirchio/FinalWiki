//
//  ChatView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 6/14/25.
//
//  Purpose:
//  - Provides a one-on-one messaging screen between the
//    logged-in user and another selected user. Handles loading
//    conversation history, sending new messages to CloudKit,
//    and displaying them in a scrollable chat layout.
//

import SwiftUI
import CloudKit

struct ChatView: View {
    let currentUser: User
    let otherUser: User

    @State private var messages: [Message] = []
    @State private var newMessage = ""
    @State private var isLoading = true
    @State private var showSendConfirmation = false

    var body: some View {
        VStack {
            // Confirmation banner
            if showSendConfirmation {
                Text("Message sent")
                    .foregroundColor(.green)
                    .transition(.opacity)
            }

            // Scrollable conversation area
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(messages) { message in
                            HStack {
                                if message.sender.id == currentUser.id {
                                    // Current user's messages: right aligned, blue bubble
                                    Spacer()
                                    VStack(alignment: .trailing) {
                                        Text(message.content)
                                            .padding(10)
                                            .background(Color.primaryBlue)
                                            .foregroundColor(.white)
                                            .cornerRadius(12)

                                        HStack(spacing: 4) {
                                            Text(formatTime(message.timestamp))
                                                .font(.caption2)
                                                .foregroundColor(.white.opacity(0.7))
                                            Image(systemName: "checkmark.circle.fill")
                                                .foregroundColor(.green)
                                                .font(.caption2)
                                        }
                                    }
                                } else {
                                    // Other user's messages: left aligned, gray bubble
                                    VStack(alignment: .leading) {
                                        Text(message.content)
                                            .padding(10)
                                            .background(Color.gray.opacity(0.2))
                                            .cornerRadius(12)

                                        Text(formatTime(message.timestamp))
                                            .font(.caption2)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                }
                            }
                            .id(message.id) // Used for automatic scrolling
                        }
                    }
                    .padding()
                }
                .onChange(of: messages.count) { _ in
                    // Scroll to the newest message whenever one is added
                    if let last = messages.last {
                        proxy.scrollTo(last.id, anchor: .bottom)
                    }
                }
            }

            Divider()

            // Input field and send button
            HStack {
                TextField("Type a message...", text: $newMessage)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                Button(action: sendMessage) {
                    Image(systemName: "paperplane.fill")
                        .foregroundColor(.primaryBlue)
                }
                .disabled(newMessage.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding()
        }
        .navigationTitle(otherUser.username)
        .onAppear {
            // Initial load and set up CloudKit push listener
            print("ChatView appeared for user: \(otherUser.username)")
            loadMessages()

            NotificationCenter.default.addObserver(
                forName: .cloudKitSubscriptionNotificationReceived,
                object: nil,
                queue: .main
            ) { _ in
                print("CloudKit subscription fired – reloading messages.")
                loadMessages()
            }
        }
        .onDisappear {
            // Remove observer to avoid memory leaks
            NotificationCenter.default.removeObserver(self, name: .cloudKitSubscriptionNotificationReceived, object: nil)
        }

    }

    // MARK: - Format timestamp
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    // MARK: - Load messages
    private func loadMessages() {
        print("Attempting to load messages between \(currentUser.username) and \(otherUser.username)")

        CloudKitManager.shared.fetchMessages(between: currentUser, and: otherUser) { fetchedMessages in
            print("Loaded \(fetchedMessages.count) messages between \(currentUser.username) and \(otherUser.username)")
            self.messages = fetchedMessages
            self.isLoading = false
        }
    }


    // MARK: - Send message
    private func sendMessage() {
        let trimmed = newMessage.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        let message = Message(
            id: CKRecord.ID(),
            sender: currentUser,
            recipient: otherUser,
            content: trimmed,
            timestamp: Date()
        )

        CloudKitManager.shared.saveMessage(message) { success in
            DispatchQueue.main.async {
                if success {
                    // Update UI instantly and show confirmation banner
                    self.messages.append(message)
                    self.newMessage = ""
                    self.showSendConfirmation = true

                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        self.showSendConfirmation = false
                    }
                } else {
                    print("Failed to send message.")
                }
            }
        }
    }
}
