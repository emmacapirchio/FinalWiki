//
//  UserListView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 6/14/25.
//
//  Purpose:
//  - Displays all other registered users so the logged-in
//    employee can start a direct chat with them. Filters out the
//    current user and provides navigation to a ChatView for each
//    selected user.
//

import SwiftUI

struct UserListView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var selectedUser: User?

    var body: some View {
        NavigationView {
            if let currentUser = viewModel.loggedInUser {
                // List all users except the one currently logged in
                List(viewModel.users.filter { $0.id != currentUser.id }, id: \.id) { user in
                    NavigationLink(destination: ChatView(currentUser: currentUser, otherUser: user)) {
                        VStack(alignment: .leading) {
                            Text(user.username)
                                .font(.headline)
                            Text(user.role.rawValue.capitalized)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                    }
                }
                .navigationTitle("Messages")
                .onAppear {
                    // Refresh user list when view appears
                    viewModel.loadUsers()
                    print("Loaded users:")
                    for user in viewModel.users {
                        print("\(user.username) – \(user.role.rawValue)")
                    }

                }
            } else {
                // Show a loading indicator while the current user is being retrieved
                ProgressView("Loading...")
                    .onAppear {
                        viewModel.loadUsers()
                    }
            }
        }
    }
}
