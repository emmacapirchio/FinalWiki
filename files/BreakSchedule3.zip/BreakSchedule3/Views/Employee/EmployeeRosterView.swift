//
//  EmployeeRosterView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/1/24.
//
//  Purpose:
//  - Allows Store Directors to view, add, reorder, edit, and delete
//    employees in the BreakSchedule app. All changes sync with CloudKit.
//    Includes a simple form to create new employees and a list to manage them.
//

import SwiftUI

struct EmployeeRosterView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var username = ""
    @State private var selectedRole: EmployeeRole = .tm
    @State private var department = "General"
    @State private var isEditingEmployee = false
    @State private var employeeToEdit: Employee?

    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        VStack {
            Text("Employee Roster")
                .font(.largeTitle)
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .cornerRadius(10)

            // Add Employee Form
            VStack(spacing: 10) {
                TextField("Enter Employee Name", text: $username)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .background(Color.white)
                    .cornerRadius(8)
                    .shadow(radius: 2)

                Picker("Role", selection: $selectedRole) {
                    ForEach(EmployeeRole.allCases, id: \.self) { role in
                        Text(role.displayName).tag(role)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding(.horizontal)

                TextField("Enter Department", text: $department)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .background(Color.white)
                    .cornerRadius(8)
                    .shadow(radius: 2)
            }
            .padding()
            .background(Color(UIColor.systemGray6))
            .cornerRadius(10)
            .shadow(radius: 5)
            .padding()

            // Add Button
            Button("Add Employee") {
                if !username.trimmingCharacters(in: .whitespaces).isEmpty {
                    let cleanedUsername = username.trimmingCharacters(in: .whitespaces)
                    AuthManager.shared.createUser(
                        username: username.trimmingCharacters(in: .whitespaces),
                        role: selectedRole.rawValue,
                        department: department,
                        password: "Password1" // Or prompt for it if needed
                    ) { result in
                        switch result {
                        case .success:
                            viewModel.fetchAllEmployees()
                        case .failure(let error):
                            print("Failed to create user: \(error.localizedDescription)")
                        }
                    }
                    resetInputFields()
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(username.isEmpty ? Color.gray : Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
            .shadow(radius: 3)
            .disabled(username.isEmpty)
            .padding(.horizontal)

            // Employee List
            if viewModel.employees.isEmpty {
                Text("No employees found.")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List {
                    ForEach(viewModel.employees, id: \.id) { employee in
                        HStack {
                            Text(employee.name)
                                .font(.headline)
                            Spacer()
                            Text(EmployeeRole(rawValue: employee.role)?.displayName ?? employee.role.capitalized)
                                .foregroundColor(color(for: employee.role))
                                .bold()
                        }
                        .swipeActions {
                            Button("Edit") {
                                employeeToEdit = employee
                                isEditingEmployee = true
                            }
                            .tint(.yellow)

                            Button(role: .destructive) {
                                viewModel.deleteUser(employee: employee)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                    .onMove(perform: moveEmployee)
                }
                .listStyle(InsetGroupedListStyle())
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 5)
        .onAppear {
            viewModel.fetchAllEmployees()
        }
        .sheet(isPresented: $isEditingEmployee) {
            if let employeeToEdit = employeeToEdit {
                EditEmployeeView(viewModel: viewModel, employee: employeeToEdit)
            }
        }
    }

    // Reset form inputs after a successful add
    private func resetInputFields() {
        username = ""
        selectedRole = .tm
        department = "General"
    }

    // Update employee order in CloudKit
    private func moveEmployee(from source: IndexSet, to destination: Int) {
        viewModel.moveEmployee(from: source, to: destination)
    }

    // Assigns a color to each role for easy visual distinction
    private func color(for role: String) -> Color {
        switch EmployeeRole(rawValue: role) {
        case .storeDirector: return .red
        case .etl: return .orange
        case .tl: return .blue
        case .tm: return .gray
        case .none: return .secondary
        }
    }
}
