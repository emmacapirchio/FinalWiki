//
//  EmployeeSelectionView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/1/24.
//
//  Purpose:
//  - Lets Store Directors, ETLs, and Team Leads choose employees
//    for schedule creation. Supports sorting, single/multi-selection, and
//    “Select All / Deselect All” convenience toggles. Selected employees are
//    passed to ShiftInputView to set shift times and breaks.
//

import SwiftUI

struct EmployeeSelectionView: View {
    // Main data model and CloudKit access
    @ObservedObject var viewModel: ScheduleViewModel
    // Tracks global select/deselect state
    @State private var isAllSelected = false

    var body: some View {
        NavigationView {
            VStack {
                // Sorting and select-all controls
                HStack {
                    Menu {
                        Button("Sort A → Z") {
                            viewModel.sortEmployees(ascending: true)
                        }
                        Button("Sort Z → A") {
                            viewModel.sortEmployees(ascending: false)
                        }
                    } label: {
                        Label("Sort Options", systemImage: "arrow.up.arrow.down.circle")
                            .foregroundColor(.primary)
                    }

                    Spacer()

                    Button(isAllSelected ? "Deselect All" : "Select All") {
                        toggleSelectAll()
                    }
                    .buttonStyle(.bordered)
                }
                .padding(.horizontal)

                // Employee list with tap-to-select behavior
                List(viewModel.employees, id: \.id) { employee in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(employee.name)
                                .font(.headline)
                            Text("Role: \(EmployeeRole(rawValue: employee.role)?.displayName ?? employee.role.capitalized)")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }

                        Spacer()

                        // Show a checkmark when selected
                        if viewModel.selectedEmployees.contains(where: { $0.id == employee.id }) {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                        }
                    }
                    .contentShape(Rectangle()) // Make the whole row tappable
                    .onTapGesture {
                        toggleSelection(for: employee)
                    }
                }
            }
            .navigationTitle("Select Employees")
            .toolbar {
                // Next button navigates to shift input only if at least one employee is selected
                NavigationLink(destination: ShiftInputView(viewModel: viewModel)) {
                    Text("Next")
                }
                .disabled(viewModel.selectedEmployees.isEmpty)
            }
            .onAppear {
                viewModel.fetchAllEmployees()
            }
        }
    }

    // Adds or removes an employee from the selected list
    private func toggleSelection(for employee: Employee) {
        if let index = viewModel.selectedEmployees.firstIndex(where: { $0.id == employee.id }) {
            viewModel.selectedEmployees.remove(at: index)
        } else {
            let shift = EmployeeShift(
                id: employee.id,
                employeeID: employee.id,
                name: employee.name,
                role: employee.role,
                department: employee.department,
                shiftStart: Date(),
                shiftEnd: Date().addingTimeInterval(8 * 3600),
                notes: NoteType.opu.rawValue,
                goals: ""
            )
            viewModel.selectedEmployees.append(shift)
        }
    }

    // Selects or deselects all employees at once
    private func toggleSelectAll() {
        if isAllSelected {
            viewModel.selectedEmployees = []
        } else {
            viewModel.selectedEmployees = viewModel.employees.map { employee in
                EmployeeShift(
                    id: employee.id,
                    employeeID: employee.id,
                    name: employee.name,
                    role: employee.role,
                    department: employee.department,
                    shiftStart: Date(),
                    shiftEnd: Date().addingTimeInterval(8 * 3600),
                    notes: NoteType.opu.rawValue,
                    goals: ""
                )
            }
        }
        isAllSelected.toggle()
    }
}
