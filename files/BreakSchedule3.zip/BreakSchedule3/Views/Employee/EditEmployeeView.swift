//
//  EditEmployeeView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/6/25.
//
//  Purpose:
//  - Presents a form that allows Store Directors to edit an existing
//    employee’s name, role, and department. Updates the employee record in
//    CloudKit through ScheduleViewModel and dismisses when done.
//

import SwiftUI

struct EditEmployeeView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var name: String
    @State private var role: EmployeeRole
    @State private var department: String
    @State private var showAlert = false

    // Employee being edited
    let employee: Employee
    // Used to close the view after saving or cancelling
    @Environment(\.dismiss) var dismiss

    init(viewModel: ScheduleViewModel, employee: Employee) {
        self.viewModel = viewModel
        self.employee = employee
        // Pre-fill fields with the current employee data
        _name = State(initialValue: employee.name)
        _role = State(initialValue: EmployeeRole(rawValue: employee.role) ?? .tm)
        _department = State(initialValue: employee.department)
    }

    var body: some View {
        NavigationView {
            Form {
                // Section for editing the employee’s basic information
                Section(header: Text("Employee Info")) {
                    TextField("Name", text: $name)
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                    Picker("Role", selection: $role) {
                        ForEach(EmployeeRole.allCases, id: \.self) { role in
                            Text(role.displayName).tag(role)
                        }
                    }

                    TextField("Department", text: $department)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                }

                // Section with a save button that validates input and updates CloudKit
                Section {
                    Button("Save Changes") {
                        if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            showAlert = true
                        } else {
                            saveChanges()
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
            }
            .navigationTitle("Edit Employee")
            .navigationBarItems(trailing: Button("Cancel") {
                dismiss()
            })
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Invalid Name"),
                    message: Text("Employee name cannot be empty."),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }

    // Save changes back to CloudKit via ScheduleViewModel, then dismiss the view
    private func saveChanges() {
        viewModel.updateEmployee(
            employee: employee,
            newName: name.trimmingCharacters(in: .whitespacesAndNewlines),
            newRole: role.rawValue,
            newDepartment: department
        )
        dismiss()
    }
}
