//
//  SidebarView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/5/24.
//
//  Purpose:
//  - Provides the main navigation menu (sidebar) for all user roles
//    (Store Director, ETL, TL, and TM). Shows appropriate links based on the
//    logged-in user’s role and includes admin utilities such as testing
//    notifications, auditing CloudKit subscriptions, and viewing a debug console.
//

import SwiftUI
import UserNotifications
import CloudKit

struct SidebarView: View {
    // Shared view model for schedule and user data
    @ObservedObject var viewModel: ScheduleViewModel
    // Controls visibility of the debug overlay
    @State private var showDebugConsole = false

    var body: some View {
        ZStack {
            NavigationView {
                List {
                    Section(header: Text("Menu").font(.headline).foregroundColor(.primaryBlue)) {
                        // Role-based menu layout
                        switch viewModel.loggedInUser?.role {
                        case .storeDirector:
                            Group {
                                NavigationLink(destination: EmployeeRosterView(viewModel: viewModel)) {
                                    Label("Employee Roster", systemImage: "person.3")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: EmployeeSelectionView(viewModel: viewModel)) {
                                    Label("Create Schedule", systemImage: "calendar.badge.plus")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: PastSchedulesView(viewModel: viewModel)) {
                                    Label("Past Schedules", systemImage: "clock.arrow.circlepath")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: SwapApprovalView().environmentObject(viewModel)) {
                                    Label("Approve Swap Requests", systemImage: "checkmark.circle")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: SchedulePDFExportView(viewModel: viewModel).environmentObject(viewModel)) {
                                    Label("Export Schedule PDF", systemImage: "doc.fill")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: FAQView()) {
                                    Label("FAQs", systemImage: "questionmark.circle")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: UserListView(viewModel: viewModel)) {
                                    Label("Messages", systemImage: "message")
                                        .foregroundColor(.primaryBlue)
                                }
                            }

                        case .etl, .tl:
                            Group {
                                NavigationLink(destination: EmployeeSelectionView(viewModel: viewModel)) {
                                    Label("Create Schedule", systemImage: "calendar.badge.plus")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: PastSchedulesView(viewModel: viewModel)) {
                                    Label("Past Schedules", systemImage: "clock.arrow.circlepath")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: SwapApprovalView().environmentObject(viewModel)) {
                                    Label("Approve Swap Requests", systemImage: "checkmark.circle")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: FAQView()) {
                                    Label("FAQs", systemImage: "questionmark.circle")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: UserListView(viewModel: viewModel)) {
                                    Label("Messages", systemImage: "message")
                                        .foregroundColor(.primaryBlue)
                                }
                            }

                        case .tm:
                            Group {
                                NavigationLink(destination: MyBreakScheduleView(viewModel: viewModel)) {
                                    Label("My Break Schedule", systemImage: "calendar")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: SwapInboxView().environmentObject(viewModel)) {
                                    Label("Swap Requests", systemImage: "arrow.triangle.2.circlepath")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: FAQView()) {
                                    Label("FAQs", systemImage: "questionmark.circle")
                                        .foregroundColor(.primaryBlue)
                                }
                                NavigationLink(destination: UserListView(viewModel: viewModel)) {
                                    Label("Messages", systemImage: "message")
                                        .foregroundColor(.primaryBlue)
                                }
                            }

                        case .none:
                            EmptyView()
                        }

                        // Log Out
                        Button(role: .destructive) {
                            viewModel.logOut()
                        } label: {
                            Label("Log Out", systemImage: "arrow.backward.circle")
                        }

                        // Debug Console Toggle
                        Button {
                            withAnimation { showDebugConsole.toggle() }
                        } label: {
                            Label("Debug Console", systemImage: "wrench.and.screwdriver")
                                .foregroundColor(.orange)
                        }

                        // Test local notification (banners)
                        Button {
                            let content = UNMutableNotificationContent()
                            content.title = "Test Notification"
                            content.body  = "If you see this, banners are enabled."
                            content.sound = .default
                            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
                            let id = UUID().uuidString
                            UNUserNotificationCenter.current().add(
                                UNNotificationRequest(identifier: id, content: content, trigger: trigger)
                            ) { err in
                                appLog(err == nil
                                       ? "Scheduled local test notification (\(id))."
                                       : "Local test failed: \(err!.localizedDescription)")
                            }
                        } label: {
                            Label("Test Local Notification", systemImage: "bell.badge")
                                .foregroundColor(.orange)
                        }

                        // Audit / fix CloudKit subscriptions in PRODUCTION
                        Button {
                            if let u = viewModel.loggedInUser {
                                CloudKitManager.shared.auditAndFixSubscriptions(for: u)
                            } else {
                                appLog("No logged-in user; cannot audit subscriptions.")
                            }
                        } label: {
                            Label("Audit Push Subscriptions", systemImage: "icloud.and.arrow.down")
                                .foregroundColor(.orange)
                        }
                        
                        // CloudKit push test – save a Message to yourself
                        Button {
                            if let u = viewModel.loggedInUser {
                                CloudKitManager.shared.sendTestCloudKitMessage(to: u)
                            } else {
                                appLog("No logged-in user; cannot send test message.")
                            }
                        } label: {
                            Label("Send CloudKit Test Message", systemImage: "paperplane.fill")
                                .foregroundColor(.orange)
                        }
                    }
                }
                .navigationTitle("Menu")
                .background(Color.primaryBlue.opacity(0.1))
                .scrollContentBackground(.hidden)
            }

            // Debug console overlay
            if showDebugConsole {
                DebugConsoleView(isPresented: $showDebugConsole)
                    .transition(.move(edge: .bottom))
                    .zIndex(1)
            }
        }
    }
}
