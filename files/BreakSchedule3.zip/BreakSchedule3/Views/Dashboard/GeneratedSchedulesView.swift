//
//  GeneratedSchedulesView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/12/25.
//
//  Purpose:
//  - Display newly generated schedules and allow saving them to
//    the user's past schedules history in CloudKit.
//

import SwiftUI

struct GeneratedSchedulesView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @Environment(\.dismiss) var dismiss
    @State private var hasSaved = false
    var generatedSchedules: [Schedule]
    
    var body: some View {
        VStack {
            Text("Generated Schedules")
                .font(.largeTitle)
                .padding()

            // List each generated schedule with basic details
            List(generatedSchedules, id: \.id) { schedule in
                VStack(alignment: .leading) {
                    Text(schedule.name).font(.headline)
                    Text("Shift: \(schedule.shift)").font(.subheadline)
                    Text("First Break: \(schedule.firstBreak)")
                    Text("Lunch Break: \(schedule.lunchBreak)")
                    Text("Second Break: \(schedule.secondBreak)")
                }
            }

            // Save all generated schedules to CloudKit as past schedules
            Button("Save to Past Schedules") {
                for schedule in generatedSchedules {
                    viewModel.saveToPastSchedules(schedule: schedule)
                }
                hasSaved = true
                print("Schedules saved to past schedules!")
            }
            .disabled(hasSaved)
            .opacity(hasSaved ? 0.5 : 1.0)
            .buttonStyle(.borderedProminent)
            .padding()

            // Return to the main schedule view
            Button("Back to Schedule") {
                dismiss()
            }
            .buttonStyle(.borderedProminent)
            .padding()
        }
        .padding()
    }
}
