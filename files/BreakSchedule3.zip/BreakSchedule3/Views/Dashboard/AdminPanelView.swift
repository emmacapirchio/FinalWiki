//
//  AdminPanelView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/6/25.
//
//  Purpose:
//  - Store Director dashboard to view, manage, and delete user accounts.
//

import SwiftUI

struct AdminPanelView: View {
    // Shared app data and user management logic
    @ObservedObject var viewModel: ScheduleViewModel

    var body: some View {
        VStack {
            Text("Store Director Dashboard")
                .font(.largeTitle)
                .bold()
                .padding(.top)

            // List of all users pulled from CloudKit
            List {
                ForEach(viewModel.users) { user in
                    HStack {
                        // Display username
                        Text(user.username)
                            .fontWeight(.medium)

                        Spacer()

                        // Display user role with color coding
                        Text(user.role.displayName)
                            .foregroundColor(color(for: user.role))
                            .bold()
                    }
                    // Swipe left to reveal delete option for each user
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) {
                            confirmDeletion(for: user)
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
                }
            }

            Spacer()
        }
        .padding()
        .navigationTitle("Admin Panel")
        .onAppear {
            if viewModel.users.isEmpty {
                viewModel.loadUsers()
            }
        }
    }

    // MARK: - Helper Methods
    // Assign a color to each user role for quick visual distinction
    func color(for role: EmployeeRole) -> Color {
        switch role {
        case .storeDirector: return .red
        case .etl: return .orange
        case .tl: return .blue
        case .tm: return .gray
        }
    }

    // Convert a User model to an Employee model and call delete function
    func confirmDeletion(for user: User) {
        let employee = Employee(
            id: user.id,
            name: user.username,
            role: user.role.rawValue,
            department: user.department
        )
        viewModel.deleteUser(employee: employee)
    }
}

