//
//  ChangePasswordView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/12/25.
//
//  Purpose:
//  - Simple screen for users who must reset their password after login.
//
//  Notes:
//   - Compares new/confirm fields.
//   - Calls AuthManager to update password in CloudKit if the two match.
//

import SwiftUI

struct ChangePasswordView: View {
    // Local form state for entering a new password twice
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    // Access to the logged-in user (needed to know which username to update)
    @ObservedObject var viewModel: ScheduleViewModel

    var body: some View {
        VStack {
            Text("Change your password")
                .font(.title)
                .padding()

            SecureField("New Password", text: $newPassword)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())

            SecureField("Confirm New Password", text: $confirmPassword)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())

            Button(action: {
                if newPassword == confirmPassword {
                    // Call the function to update the password in AuthManager
                    if let username = viewModel.loggedInUser?.username {
                        AuthManager.shared.changePassword(username: username, newPassword: newPassword) { result in
                            switch result {
                            case .success(let message):
                                print(message)
                            case .failure(let error):
                                print("Error changing password: \(error.localizedDescription)")
                            }
                        }
                    }
                } else {
                    // Show error if passwords do not match
                    print("Passwords do not match!")
                }
            }) {
                Text("Save New Password")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
