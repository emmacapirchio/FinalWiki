//
//  LoginView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/1/24.
//
//  Purpose:
//  - SwiftUI login screen that supports username/password login
//    and Sign in with Apple. Displays error messages and navigates to registration
//    or password change when needed.
//

// Original View
/*import SwiftUI

struct LoginView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var username = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("Login")
                .font(.largeTitle)
                .bold()

            TextField("Enter your username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button("Log In") {
                viewModel.logIn(username: username)
            }
            .buttonStyle(.borderedProminent)
            .disabled(username.isEmpty)

            Spacer()
        }
        .padding()
    }
}*/

import SwiftUI
import AuthenticationServices

struct LoginView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var username = ""
    @State private var password = ""
    @State private var showChangePasswordView = false
    @State private var loginError: String?  // State to hold error message

    var body: some View {
        VStack(spacing: 20) {
            Text("Login")
                .font(.largeTitle)
                .bold()
            
            TextField("Username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            // Display error message if login fails
            if let error = loginError {
                Text(error)
                    .foregroundColor(.red)
                    .padding()
            }
            
            Button("Log In") {
                viewModel.loginUser(username: username, password: password) { success, error in
                    if success {
                        loginError = nil
                        print("Login successful")
                    } else {
                        loginError = error ?? "Wrong username or password"
                    }
                }
            }
            .buttonStyle(.borderedProminent)
            .padding()
            
            // Register Button
            NavigationLink("Don't have an account? Register", destination: SignUpView(viewModel: viewModel))
                .padding()
                .foregroundColor(.blue)
            
            Spacer()
            
            SignInWithAppleButton(
                .signIn,
                onRequest: { request in
                    request.requestedScopes = [.fullName, .email]
                },
                onCompletion: { result in
                    switch result {
                    case .success(let authResults):
                        viewModel.logInWithApple(authResults: authResults) { success, error in
                            if success {
                                loginError = nil
                            } else {
                                loginError = error ?? "Apple Sign-In failed."
                            }
                        }
                    case .failure(let error):
                        loginError = "Apple Sign-In failed: \(error.localizedDescription)"
                    }
                }
            )
            .frame(width: 280, height: 45)
            .signInWithAppleButtonStyle(.black)

            Spacer()
        }
        .padding()
        .sheet(isPresented: $viewModel.showChangePasswordView) {
            ChangePasswordView(viewModel: viewModel)
        }
    }
}
