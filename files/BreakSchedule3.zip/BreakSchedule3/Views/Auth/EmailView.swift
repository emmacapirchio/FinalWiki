//
//  EmailView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/5/24.
//
//  Purpose:
//  - Wraps Apple's MFMailComposeViewController so SwiftUI can present
//    a pre-filled email composer with optional PDF attachment (e.g., schedules).
//

import MessageUI
import SwiftUI

// SwiftUI wrapper around the system mail composer
struct EmailView: UIViewControllerRepresentable {
    let subject: String
    let recipients: [String]
    let attachmentData: Data?
    let fileName: String

    // Coordinator acts as delegate to handle composer callbacks
    class Coordinator: NSObject, MFMailComposeViewControllerDelegate {
        var parent: EmailView

        init(parent: EmailView) {
            self.parent = parent
        }

        // Called when the mail composer finishes
        func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
            if let error = error {
                print("Mail error: \(error.localizedDescription)")
            }
            controller.dismiss(animated: true, completion: nil)
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    // Create and configure the mail composer
    func makeUIViewController(context: Context) -> MFMailComposeViewController {
        guard MFMailComposeViewController.canSendMail() else {
            print("Cannot send mail - Mail services not available")
            return MFMailComposeViewController()
        }

        let vc = MFMailComposeViewController()
        vc.mailComposeDelegate = context.coordinator
        vc.setSubject(subject)
        vc.setToRecipients(recipients)
        // Attach file if provided
        if let data = attachmentData {
            vc.addAttachmentData(data, mimeType: "application/pdf", fileName: fileName)
        }
        return vc
    }

    // No dynamic updates needed after initial creation
    func updateUIViewController(_ uiViewController: MFMailComposeViewController, context: Context) {}
}
