//
//  SignUpView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/6/25.
//
//  Purpose:
//  - Registration screen that allows a new user to create
//    an account with username, password, and department.
//

import SwiftUI

struct SignUpView: View {
    @ObservedObject var viewModel: ScheduleViewModel
    @State private var username = ""
    @State private var password = ""
    @State private var department = ""
    @State private var registrationMessage = ""
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack(spacing: 20) {
            Text("Register")
                .font(.largeTitle)
                .bold()

            TextField("Username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            TextField("Department", text: $department)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            // Register button
            Button(action: {
                // Check for empty fields
                guard !username.isEmpty, !password.isEmpty, !department.isEmpty else {
                    registrationMessage = "Please fill out all fields."
                    return
                }

                // Call shared AuthManager to create the user in CloudKit
                AuthManager.shared.registerUser(username: username, password: password, department: department) { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success:
                            registrationMessage = "Registration successful! Redirecting..."
                            // Dismiss the view after a short delay
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                presentationMode.wrappedValue.dismiss()
                            }
                        case .failure(let error):
                            registrationMessage = "Error: \(error.localizedDescription)"
                        }
                    }
                }
            }) {
                Text("Register")
            }
            .buttonStyle(.borderedProminent)
            .padding()

            // Show success or error message in appropriate color
            Text(registrationMessage)
                .foregroundColor(registrationMessage.contains("successful") ? .green : .red)
                .padding()

            Spacer()
        }
        .padding()
    }
}
