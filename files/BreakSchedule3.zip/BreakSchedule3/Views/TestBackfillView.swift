//
//  TestBackfillView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 4/28/25.
//
//  Purpose:
//  - Provides an internal testing screen to run a one-time backfill
//    process that updates missing employeeID fields in existing CloudKit records.
//    Useful for maintenance and data migration.
//


import SwiftUI

struct TestBackfillView: View {
    // Tracks whether the backfill is currently running
    @State private var isRunning = false
    // Stores a success or error message after the run
    @State private var resultMessage: String = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("Backfill EmployeeIDs")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.primary)

            // Button to start the backfill job
            Button(action: runBackfill) {
                Text(isRunning ? "Running..." : "Run Backfill")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isRunning ? Color.gray : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(isRunning) // Prevent multiple simultaneous runs

            // Display the result once the job finishes
            if !resultMessage.isEmpty {
                Text(resultMessage)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding()
            }
        }
        .padding()
    }

    // MARK: - Backfill Runner
    private func runBackfill() {
        isRunning = true
        resultMessage = ""

        BackfillHelper.backfillEmployeeIDs { result in
            isRunning = false

            switch result {
            case .success:
                resultMessage = "Backfill completed successfully!"
            case .failure(let error):
                resultMessage = "Backfill failed: \(error.localizedDescription)"
            }
        }
    }
}
