//
//  Models.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 11/25/24.
//
//  Purpose:
//  - Core data types used by the app (users, employees, schedules,
//  shifts, messages, and simple helpers).
//
//  Notes:
//  - CloudKit bridging uses CKRecord.ID for stable identity.
//  - Coding/decoding converts CKRecord.ID <-> recordName (String).
//  - Keep record type/field names centralized to avoid string drift.
//

import Foundation
import CloudKit

// MARK: - Department Notes (helper)
// Quick lookup of suggested "notes" choices by department.
// UI uses this to populate a Picker for department-specific tasks.
struct DepartmentNotes {
    static let fulfillmentNotes: [String] = ["OPU", "SFS", "TL"]
    static let frontendNotes: [String] = ["Cashier", "Self Checkout", "Guest Service"]
    static let inboundNotes: [String] = ["Unload", "Backstock", "Stocking"]
    // Add more departments as needed

    // Returns suggested notes for a given department (case-insensitive).
    static func notes(for department: String) -> [String] {
        switch department.lowercased() {
        case "fulfillment": return fulfillmentNotes
        case "front end", "frontend", "front-end": return frontendNotes
        case "inbound": return inboundNotes
        default: return []
        }
    }
}

// MARK: - NoteType
// Enumerates common "notes" options used in schedules/shifts.
enum NoteType: String, CaseIterable, Codable {
    case opu = "OPU"
    case sfs = "SFS"
    case tl = "TL"
    case cashier = "Cashier"
    case selfCheckout = "Self Checkout"
    case guestService = "Guest Service"
    case unload = "Unload"
    case backstock = "Backstock"
    case stocking = "Stocking"
    case general = "General"
}

// MARK: - Schedule (legacy printable schedule row)
// A printable/legacy schedule row (distinct from EmployeeShift).
// Kept Codable for local persistence/exports and bridging to EmployeeShift.
struct Schedule: Identifiable, Codable {
    var id = UUID()
    var employeeID: UUID = UUID()
    var name: String
    var shift: String
    var firstBreak: String
    var lunchBreak: String
    var secondBreak: String
    var notes: NoteType
    var goals: String
    var date: Date? = nil
    var shiftStart: Date = Date()
    var shiftEnd: Date = Date().addingTimeInterval(8 * 3600)

    enum CodingKeys: String, CodingKey {
        case id, employeeID, name, shift, firstBreak, lunchBreak, secondBreak, notes, goals, date, shiftStart, shiftEnd
    }

    // Defensive decoding: supply defaults if fields are missing.
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        employeeID = try container.decodeIfPresent(UUID.self, forKey: .employeeID) ?? UUID()
        name = try container.decode(String.self, forKey: .name)
        shift = try container.decode(String.self, forKey: .shift)
        firstBreak = try container.decode(String.self, forKey: .firstBreak)
        lunchBreak = try container.decode(String.self, forKey: .lunchBreak)
        secondBreak = try container.decode(String.self, forKey: .secondBreak)
        let notesRaw = try container.decodeIfPresent(String.self, forKey: .notes) ?? "General"
        notes = NoteType(rawValue: notesRaw) ?? .general
        goals = try container.decodeIfPresent(String.self, forKey: .goals) ?? ""
        date = try container.decodeIfPresent(Date.self, forKey: .date)
        shiftStart = try container.decodeIfPresent(Date.self, forKey: .shiftStart) ?? Date()
        shiftEnd = try container.decodeIfPresent(Date.self, forKey: .shiftEnd) ?? Date().addingTimeInterval(8 * 3600)
    }

    init(
        id: UUID = UUID(),
        employeeID: UUID = UUID(),
        name: String,
        shift: String,
        firstBreak: String,
        lunchBreak: String,
        secondBreak: String,
        notes: NoteType,
        goals: String = "",
        date: Date = Date(),
        shiftStart: Date = Date(),
        shiftEnd: Date = Date().addingTimeInterval(8 * 3600)
    ) {
        self.id = id
        self.employeeID = employeeID
        self.name = name
        self.shift = shift
        self.firstBreak = firstBreak
        self.lunchBreak = lunchBreak
        self.secondBreak = secondBreak
        self.notes = notes
        self.goals = goals
        self.date = date
        self.shiftStart = shiftStart
        self.shiftEnd = shiftEnd
    }
}


// MARK: - Employee
// Represents a single employee (CloudKit-backed).
// Uses CKRecord.ID for stable, server-side identity.
struct Employee: Identifiable, Codable, Equatable {
    let id: CKRecord.ID
    let name: String
    let role: String
    let department: String
    var password: String? = nil
    var needsPasswordChange: Bool = false
    var managerUsername: String? = nil

    enum CodingKeys: String, CodingKey {
        case id, name, role, department, password, needsPasswordChange, managerUsername
    }

    init(id: CKRecord.ID, name: String, role: String, department: String, password: String? = nil, needsPasswordChange: Bool = false, managerUsername: String? = nil) {
        self.id = id
        self.name = name
        self.role = role
        self.department = department
        self.password = password
        self.needsPasswordChange = needsPasswordChange
        self.managerUsername = managerUsername
    }

    // Convert recordName <-> CKRecord.ID for Codable compatibility.
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let idString = try container.decode(String.self, forKey: .id)
        id = CKRecord.ID(recordName: idString)

        name = try container.decode(String.self, forKey: .name)
        role = try container.decode(String.self, forKey: .role)
        department = try container.decode(String.self, forKey: .department)
        password = try container.decodeIfPresent(String.self, forKey: .password)
        needsPasswordChange = try container.decodeIfPresent(Bool.self, forKey: .needsPasswordChange) ?? false
        managerUsername = try container.decodeIfPresent(String.self, forKey: .managerUsername)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id.recordName, forKey: .id)
        try container.encode(name, forKey: .name)
        try container.encode(role, forKey: .role)
        try container.encode(department, forKey: .department)
        try container.encodeIfPresent(password, forKey: .password)
        try container.encode(needsPasswordChange, forKey: .needsPasswordChange)
        try container.encodeIfPresent(managerUsername, forKey: .managerUsername)
    }
}


// MARK: - EmployeeRole
// Role hierarchy used for authorization and UI filtering.
enum EmployeeRole: String, CaseIterable, Codable {
    case storeDirector, etl, tl, tm

    var displayName: String {
        switch self {
        case .storeDirector: return "Store Director"
        case .etl: return "ETL"
        case .tl: return "Team Lead"
        case .tm: return "Team Member"
        }
    }
}


// MARK: - EmployeeShift (CloudKit-backed shift row)
// A single person's scheduled shift (preferred over `Schedule` for CloudKit).
// Start/end optional so drafts can exist before exact times are set.
struct EmployeeShift: Identifiable, Codable {
    let id: CKRecord.ID
    let employeeID: CKRecord.ID
    let name: String
    let role: String
    let department: String
    var shiftStart: Date?
    var shiftEnd: Date?
    var notes: String // Use enum
    var goals: String
    
    init(id: CKRecord.ID, employeeID: CKRecord.ID, name: String, role: String, department: String, shiftStart: Date? = nil, shiftEnd: Date? = nil, notes: String, goals: String = "") {
        self.id = id
        self.employeeID = employeeID
        self.name = name
        self.role = role
        self.department = department
        self.shiftStart = shiftStart
        self.shiftEnd = shiftEnd
        self.notes = notes
        self.goals = goals
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case employeeID
        case name
        case role
        case department
        case shiftStart
        case shiftEnd
        case notes
        case goals
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        let idString = try container.decode(String.self, forKey: .id)
        id = CKRecord.ID(recordName: idString)

        let employeeIDString = try container.decode(String.self, forKey: .employeeID)
        employeeID = CKRecord.ID(recordName: employeeIDString)

        name = try container.decode(String.self, forKey: .name)
        role = try container.decode(String.self, forKey: .role)
        department = try container.decode(String.self, forKey: .department)
        shiftStart = try container.decodeIfPresent(Date.self, forKey: .shiftStart)
        shiftEnd = try container.decodeIfPresent(Date.self, forKey: .shiftEnd)
        notes = try container.decode(String.self, forKey: .notes)
        goals = try container.decode(String.self, forKey: .goals)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)

        try container.encode(id.recordName, forKey: .id)
        try container.encode(employeeID.recordName, forKey: .employeeID)
        try container.encode(name, forKey: .name)
        try container.encode(role, forKey: .role)
        try container.encode(department, forKey: .department)
        try container.encodeIfPresent(shiftStart, forKey: .shiftStart)
        try container.encodeIfPresent(shiftEnd, forKey: .shiftEnd)
        try container.encode(notes, forKey: .notes)
        try container.encode(goals, forKey: .goals)
    }
}


// MARK: - User
// An app user with role/department context plus cached employees/schedules.
// Note: `schedules` is a 2D array to support grouping (e.g., by day or team).
struct User: Identifiable, Codable {
    let id: CKRecord.ID
    let employeeID: UUID
    let username: String
    let role: EmployeeRole
    let department: String
    var managedDepartments: [String]? = nil
    var schedules: [[Schedule]]
    var employees: [Employee]

    enum CodingKeys: String, CodingKey {
        case id, employeeID, username, role, department, managedDepartments, schedules, employees
    }

    init(
        id: CKRecord.ID,
        employeeID: UUID = UUID(),
        username: String,
        role: EmployeeRole,
        department: String,
        managedDepartments: [String]? = nil,
        schedules: [[Schedule]] = [],
        employees: [Employee] = []
    ) {
        self.id = id
        self.employeeID = employeeID
        self.username = username
        self.role = role
        self.department = department
        self.managedDepartments = managedDepartments
        self.schedules = schedules
        self.employees = employees
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        let idString = try container.decode(String.self, forKey: .id)
            self.id = CKRecord.ID(recordName: idString)
        // id = try container.decode(CKRecord.ID.self, forKey: .id)
        employeeID = try container.decode(UUID.self, forKey: .employeeID)
        username = try container.decode(String.self, forKey: .username)
        role = try container.decode(EmployeeRole.self, forKey: .role)
        department = try container.decode(String.self, forKey: .department)
        managedDepartments = try container.decodeIfPresent([String].self, forKey: .managedDepartments)
        schedules = try container.decodeIfPresent([[Schedule]].self, forKey: .schedules) ?? []
        employees = try container.decodeIfPresent([Employee].self, forKey: .employees) ?? []
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id.recordName, forKey: .id)
        try container.encode(employeeID, forKey: .employeeID)
        try container.encode(username, forKey: .username)
        try container.encode(role, forKey: .role)
        try container.encode(department, forKey: .department)
        try container.encodeIfPresent(managedDepartments, forKey: .managedDepartments)
        try container.encode(schedules, forKey: .schedules)
        try container.encode(employees, forKey: .employees)
    }
}


// MARK: - ShiftSwapRequest (CloudKit bridge)
// Represents a shift swap request stored in CloudKit.
struct ShiftSwapRequest: Identifiable {
    let id: CKRecord.ID
    var proposerEmployeeID: String
    var proposerEmployeeName: String
    var proposerShiftID: String
    var requestedEmployeeID: String
    var requestedEmployeeName: String
    var requestedShiftID: String
    var status: String
    var approvedBy: String?
    var approvedAt: Date?
    var timestamp: Date
    
    init(record: CKRecord) {
        self.id = record.recordID
        self.proposerEmployeeID = record["proposerEmployeeID"] as? String ?? ""
        self.proposerEmployeeName = record["proposerEmployeeName"] as? String ?? ""
        self.proposerShiftID = record["proposerShiftID"] as? String ?? ""
        self.requestedEmployeeID = record["requestedEmployeeID"] as? String ?? ""
        self.requestedEmployeeName = record["requestedEmployeeName"] as? String ?? ""
        self.requestedShiftID = record["requestedShiftID"] as? String ?? ""
        self.status = record["status"] as? String ?? "PendingApproval"
        self.approvedBy = record["approvedBy"] as? String
        self.approvedAt = record["approvedAt"] as? Date ?? Date()
        self.timestamp = record["timestamp"] as? Date ?? Date()
    }
    
    func toRecord() -> CKRecord {
        let record = CKRecord(recordType: "ShiftSwapRequest")
        record["proposerEmployeeID"] = proposerEmployeeID as CKRecordValue
        record["proposerEmployeeName"] = proposerEmployeeName as CKRecordValue
        record["proposerShiftID"] = proposerShiftID as CKRecordValue
        record["requestedEmployeeID"] = requestedEmployeeID as CKRecordValue
        record["requestedEmployeeName"] = requestedEmployeeName as CKRecordValue
        record["requestedShiftID"] = requestedShiftID as CKRecordValue
        record["status"] = status as CKRecordValue
        if let approvedBy = approvedBy {
            record["approvedBy"] = approvedBy as CKRecordValue
        }
        if let approvedAt = approvedAt {
            record["approvedAt"] = approvedAt as CKRecordValue
        }
        record["timestamp"] = timestamp as CKRecordValue
        return record
    }
}

// MARK: - SwapStatus
// Canonical status values for a swap request.
// Stored as rawValue in CloudKit via ShiftSwapRequest.status.
enum SwapStatus: String {
    case pending, accepted, declined, cancelled
}

// MARK: - Bridging (Schedule -> EmployeeShift)
extension Schedule {
    // Convenience to convert a printable `Schedule` row into a CloudKit-backed `EmployeeShift`.
    // - Note: Role/department placeholders can be filled by the caller if known.
    func toEmployeeShift() -> EmployeeShift {
        return EmployeeShift(
            id: CKRecord.ID(recordName: self.id.uuidString),
            employeeID: CKRecord.ID(recordName: self.employeeID.uuidString),
            name: self.name,
            role: "TM",
            department: "",
            shiftStart: self.shiftStart,
            shiftEnd: self.shiftEnd,
            notes: self.notes.rawValue, // converting enum to string
            goals: self.goals
        )
    }
}

// MARK: - Message
// Simple message model for in-app messaging.
struct Message: Identifiable {
    let id: CKRecord.ID
    let sender: User
    let recipient: User
    let content: String
    let timestamp: Date
}
