//
//  ShakeWindow.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 8/24/25.
//
//  Purpose:
//  - Detect a physical device shake and expose it as an easy
//    SwiftUI `.onShake {}` modifier.
//
//  Notes:
//  - Shake detection uses a custom UIWindow subclass to intercept motion events.
//  - Other views can simply call `.onShake { ... }` without UIKit code.
//

import SwiftUI
import UIKit

// MARK: - Custom UIWindow that detects shakes
// Subclass of UIWindow that listens for shake gestures and posts a NotificationCenter event when detected.
class ShakeWindow: UIWindow {
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake {
            // Broadcast a notification when the device is shaken.
            NotificationCenter.default.post(name: .deviceDidShakeNotification, object: nil)
        }
        super.motionEnded(motion, with: event)
    }
}

// MARK: - Notification Name
// Notification posted when the device is shaken.
extension Notification.Name {
    static let deviceDidShakeNotification = Notification.Name("deviceDidShakeNotification")
}

// MARK: - SwiftUI ViewModifier for .onShake
// A reusable modifier so any SwiftUI view can respond to a shake.
struct DeviceShakeViewModifier: ViewModifier {
    let action: () -> Void

    func body(content: Content) -> some View {
        content
            .onReceive(NotificationCenter.default.publisher(for: .deviceDidShakeNotification)) { _ in
                action()
            }
    }
}

// MARK: - View Extension
// Convenience method to attach a shake action directly to a view.
extension View {
    func onShake(perform action: @escaping () -> Void) -> some View {
        self.modifier(DeviceShakeViewModifier(action: action))
    }
}
