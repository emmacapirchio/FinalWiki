//
//  DebugConsoleView.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 8/24/25.
//
//  Purpose:
//  - Simple in-app console to view runtime logs while testing.
//
//  Notes:
//  - `DebugLogger` is a singleton so every screen sees the same messages.
//

import SwiftUI

// MARK: - Logger (shared)
final class DebugLogger: ObservableObject {
    static let shared = DebugLogger()
    
    // Most-recent-first log lines shown in the console.
    @Published var messages: [String] = []
    
    // Keep the initializer private; use the shared singleton.
    private init() {}

    // Append a log line to the console.
    func add(_ line: String) {
        DispatchQueue.main.async {
            self.messages.append(line)
        }
    }

    // Clear all log lines.
    func clear() {
        DispatchQueue.main.async {
            self.messages.removeAll()
        }
    }
}


// MARK: - View
struct DebugConsoleView: View {
    // Whether the console sheet/panel is visible.
    @Binding var isPresented: Bool
    
    // We observe the *shared* logger. Since we don't own its lifecycle,
    // @ObservedObject is appropriate (the singleton owns itself).
    @StateObject private var logger = DebugLogger.shared
    
    // Drag amount for swipe-to-dismiss interaction.
    @State private var dragOffset: CGFloat = 0

    var body: some View {
        VStack(spacing: 0) {
            
            // MARK: Header actions
            HStack {
                Text("Debug Console")
                    .font(.headline)
                Spacer()
                
                // Copy all logs to clipboard
                Button {
                    UIPasteboard.general.string = logger.messages.joined(separator: "\n")
                } label: {
                    Image(systemName: "doc.on.doc")
                }
                .padding(.trailing, 8)

                // Clear logs
                Button(role: .destructive) {
                    logger.clear()
                } label: {
                    Image(systemName: "trash")
                }
                .padding(.trailing, 8)

                // Clear console
                Button {
                    withAnimation { isPresented = false }
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .imageScale(.large)
                }
            }
            .padding()
            .background(Color(.secondarySystemBackground))

            // MARK: Log list
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(Array(logger.messages.enumerated()), id: \.offset) { idx, line in
                            Text(line)
                                .font(.system(.footnote, design: .monospaced))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .id(idx)
                        }
                    }
                    .padding()
                }
                // Auto-scroll to bottom when a new line arrives.
                .onChange(of: logger.messages.count) { _ in
                    if let last = logger.messages.indices.last {
                        withAnimation { proxy.scrollTo(last, anchor: .bottom) }
                    }
                }
            }
        }
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .shadow(radius: 20)
        .padding(.horizontal)
        .padding(.bottom, 12)
        .offset(y: dragOffset)
        // Swipe down to dismiss (like a sheet)
        .gesture(
            DragGesture().onChanged { value in
                dragOffset = max(0, value.translation.height)
            }
            .onEnded { value in
                if value.translation.height > 80 {
                    withAnimation { isPresented = false }
                }
                dragOffset = 0
            }
        )
        .accessibilityAddTraits(.isModal)
    }
}
