//
//  Logging.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 8/24/25.
//
//  Purpose:
//  - Centralized logging utility for the app.

//  Notes:
//  - Replaces plain `print()` so every log appears in both
//    the Xcode console and the on-screen DebugLogger console.
//  - Adds filename, line, and function for easier tracing.
//


import Foundation

// Global log helper used throughout the app.
// - Parameters:
//   - message: The text to log.
//   - file, function, line: Auto-captured call-site info (no need to pass manually).
func appLog(_ message: String,
            file: String = #file,
            function: String = #function,
            line: Int = #line) {
    
    // Format file + line for context
    let filename = (file as NSString).lastPathComponent
    let formatted = "[\(filename):\(line)] \(function) – \(message)"
    
    // Standard Xcode console output
    print(formatted)
    
    // Send to on-screen DebugLogger
    DebugLogger.shared.add(formatted)
}
