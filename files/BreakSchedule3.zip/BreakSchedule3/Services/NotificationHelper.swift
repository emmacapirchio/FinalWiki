//
//  NotificationHelper.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 8/24/25.
//
//  Purpose:
//  - Small utility for requesting local/remote notification permission
//    and registering for APNS (Apple Push Notification System) when appropriate.
//
//  Notes:
//  - `requestIfNeeded` asks the user the first time (if status is `.notDetermined`).
//  - If already authorized (or provisional/ephemeral), it registers for remote pushes.
//  - `registerIfAuthorized` is a safe, non-prompting check you can call on launch.
//


import UIKit
import UserNotifications

enum NotificationHelper {
    
    // Requests notification authorization only if the status is `.notDetermined`.
    // On success (or if already authorized/provisional/ephemeral), registers for APNS.
    // - Parameter completion: Called with `true` if the app can post notifications now.
    static func requestIfNeeded(completion: @escaping (Bool) -> Void) {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            switch settings.authorizationStatus {
            case .notDetermined:
                // First run / user has not been asked yet → prompt.
                UNUserNotificationCenter.current()
                    .requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
                        if granted {
                            // Register for remote notifications (APNS) on main thread.
                            DispatchQueue.main.async {
                                UIApplication.shared.registerForRemoteNotifications()
                            }
                        }
                        completion(granted)
                    }
            case .denied:
                // User previously denied — do not re-prompt here.
                completion(false)
            case .authorized, .provisional, .ephemeral:
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
                completion(true)
            @unknown default:
                // Future statuses: fail closed.
                completion(false)
            }
        }
    }

    // Registers for APNS only if notifications are already authorized.
    // Use this on app launch to avoid prompting unexpectedly.
    static func registerIfAuthorized() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            if settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional {
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            }
        }
    }
}
