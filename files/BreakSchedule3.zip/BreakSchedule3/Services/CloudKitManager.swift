//
//  CloudKitManager.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/28/25.
//
//  Purpose:
//  - Thin wrapper around CloudKit operations used by the app.
//
//  Notes:
//   - Uses the Public DB of iCloud.com.ecapirchio.BreakSchedule unless otherwise noted.
//   - Provides convenience methods for common CRUD on Users, BreakSchedule,
//     ShiftSwapRequest, and Message records.
//   - Callers are responsible for any model/enum mapping around raw CK fields.
//

import CloudKit

class CloudKitManager {
    static let shared = CloudKitManager() // Singleton for shared access
    private init() {}
    
    // Public database for the app's container
    let publicDB = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase

    // MARK: - Fetch
    // Fetch all records of a type matching a predicate (default = all).
    func fetchRecords(ofType type: String, predicate: NSPredicate = NSPredicate(value: true), completion: @escaping ([CKRecord]?, Error?) -> Void) {
        let query = CKQuery(recordType: type, predicate: predicate)
        publicDB.perform(query, inZoneWith: nil, completionHandler: completion)
    }

    // Fetch a single record by CKRecord.ID.
    func fetchRecord(withID id: CKRecord.ID, completion: @escaping (CKRecord?, Error?) -> Void) {
        publicDB.fetch(withRecordID: id, completionHandler: completion)
    }

    // MARK: - Save
    // Save (create/update) a record to the public database
    func saveRecord(_ record: CKRecord, completion: @escaping (CKRecord?, Error?) -> Void) {
        publicDB.save(record, completionHandler: completion)
    }

    // MARK: - Delete
    // Delete a single record by ID from the public database.
    func deleteRecord(withID id: CKRecord.ID, completion: @escaping (CKRecord.ID?, Error?) -> Void) {
        publicDB.delete(withRecordID: id, completionHandler: completion)
    }

    // Delete all records of a type that match a predicate.
    // Note: This issues one delete per record (using a DispatchGroup).
    func deleteRecordsMatching(type: String, predicate: NSPredicate, completion: @escaping (Error?) -> Void) {
        fetchRecords(ofType: type, predicate: predicate) { records, error in
            guard let records = records, error == nil else {
                completion(error)
                return
            }

            let group = DispatchGroup()

            for record in records {
                group.enter()
                self.publicDB.delete(withRecordID: record.recordID) { _, _ in group.leave() }
            }

            group.notify(queue: .main) {
                completion(nil)
            }
        }
    }

    // MARK: - Users
    // Fetch a single User by username and map fields → User model.
    // Also normalizes role strings to the EmployeeRole enum.
    func fetchUser(username: String, completion: @escaping (Result<User, Error>) -> Void) {
        let predicate = NSPredicate(format: "username == %@", username)
        let query = CKQuery(recordType: "User", predicate: predicate)

        publicDB.perform(query, inZoneWith: nil) { results, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                    return
                }

                guard let record = results?.first else {
                    completion(.failure(NSError(domain: "User not found", code: 404, userInfo: nil)))
                    return
                }
                
                // Basic field extraction
                let id = record.recordID.recordName
                let username = record["username"] as? String ?? ""
                let department = record["department"] as? String ?? ""
                
                // Normalize role text (handles spacing/casing) → EmployeeRole
                let roleString = (record["role"] as? String ?? "tm").replacingOccurrences(of: " ", with: "").lowercased()
                let role: EmployeeRole
                switch roleString {
                case "storedirector": role = .storeDirector
                case "etl": role = .etl
                case "tl": role = .tl
                case "tm": role = .tm
                default: role = .tm
                }


                // Debug prints to verify mapping
                print("Logged in as: \(username)")
                print("Raw role from CloudKit: \(record["role"] as? String ?? "nil")")
                print("Normalized to: \(roleString)")
                print("Mapped to enum: \(role)")

                var employees: [Employee] = []
                if let employeesData = record["employees"] as? Data {
                    employees = (try? JSONDecoder().decode([Employee].self, from: employeesData)) ?? []
                }

                // Build minimal User model (schedules empty here)
                let user = User(
                    id: record.recordID,
                    employeeID: UUID(),
                    username: username,
                    role: role,
                    department: department,
                    managedDepartments: nil,
                    schedules: [],
                    employees: employees
                )

                completion(.success(user))
            }
        }
    }


    // Fetch all Users (basic fields) and map to User models.
    func fetchAllUsers(completion: @escaping ([User]) -> Void) {
        let predicate = NSPredicate(value: true)
        let query = CKQuery(recordType: "User", predicate: predicate)

        publicDB.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("Error fetching all users: \(error.localizedDescription)")
                    completion([])
                    return
                }

                // Map CK records → light User models
                let users: [User] = records?.compactMap { record in
                    guard
                        let username = record["username"] as? String,
                        let department = record["department"] as? String,
                        let roleRaw = record["role"] as? String,
                        let role = EmployeeRole(rawValue: roleRaw)
                    else {
                        return nil
                    }

                    let emplouyeeID = UUID()

                    var employees: [Employee] = []
                    if let data = record["employees"] as? Data {
                        employees = (try? JSONDecoder().decode([Employee].self, from: data)) ?? []
                    }

                    return User(
                        id: record.recordID,
                        employeeID: emplouyeeID,
                        username: username,
                        role: role,
                        department: department,
                        managedDepartments: nil,
                        schedules: [],
                        employees: employees
                    )
                } ?? []

                completion(users)
            }
        }
    }


    // Fetch employees (as Employee models) from "User" records.
    // Filters out the current user by record ID.
    func fetchAllEmployees(completion: @escaping ([Employee]) -> Void) {
        let query = CKQuery(recordType: "User", predicate: NSPredicate(value: true))

        publicDB.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("Error fetching employees: \(error.localizedDescription)")
                    completion([])
                    return
                }

                let employees = records?.compactMap { record -> Employee? in
                    // Require minimal fields to build an Employee
                    guard let username = record["username"] as? String,
                          let department = record["department"] as? String else {
                        print("Skipping record due to missing fields.")
                        return nil
                    }

                    // Default role → "tm" if absent
                    let role = record["role"] as? String ?? "tm" // default to team member
                    let id = UUID(uuidString: record.recordID.recordName) ?? UUID()

                    return Employee(
                        id: record.recordID,
                        name: username,
                        role: role,
                        department: department,
                        needsPasswordChange: false
                    )
                } ?? []

                //print("CloudKit returned \(employees.count) employees:")
                //employees.forEach { print("\($0.name), Role: \($0.role), Dept: \($0.department)") }

                completion(employees)
            }
        }
    }


    // MARK: - BreakSchedule (current schedules)
    // Save a Schedule as a "BreakSchedule" record in CloudKit.
    // Uses schedule.id as the recordName to keep it overwrite-safe.
    func saveSchedule(_ schedule: Schedule, department: String, completion: @escaping (Result<Void, Error>) -> Void) {
        let recordID = CKRecord.ID(recordName: schedule.id.uuidString)
        let record = CKRecord(recordType: "BreakSchedule", recordID: recordID)
        record["startTime"] = schedule.shiftStart as CKRecordValue
        record["endTime"] = schedule.shiftEnd as CKRecordValue
        record["employeeName"] = schedule.name as CKRecordValue
        record["employeeID"] = schedule.employeeID.uuidString as CKRecordValue
        record["username"] = schedule.name as CKRecordValue // optional, for swap logic
        record["department"] = department as CKRecordValue
        record["firstBreak"] = schedule.firstBreak as CKRecordValue
        record["lunchBreak"] = schedule.lunchBreak as CKRecordValue
        record["secondBreak"] = schedule.secondBreak as CKRecordValue
        record["notes"] = schedule.notes.rawValue as CKRecordValue
        record["goals"] = schedule.goals as CKRecordValue

        publicDB.save(record) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(()))
                }
            }
        }
    }

    // Delete a schedule by matching employeeName + startTime.
    func deleteSchedule(_ schedule: Schedule, completion: @escaping (Result<Void, Error>) -> Void) {
        let predicate = NSPredicate(format: "employeeName == %@ AND startTime == %@", schedule.name, schedule.shiftStart as CVarArg)
        let query = CKQuery(recordType: "BreakSchedule", predicate: predicate)

        self.publicDB.perform(query, inZoneWith: nil) { records, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let record = records?.first else {
                completion(.failure(NSError(domain: "", code: 404, userInfo: [NSLocalizedDescriptionKey: "Schedule not found."])))
                return
            }
            self.publicDB.delete(withRecordID: record.recordID) { _, deleteError in
                if let deleteError = deleteError {
                    completion(.failure(deleteError))
                } else {
                    completion(.success(()))
                }
            }
        }
    }

    // Fetch schedules visible to a specific user, based on their role.
    func fetchSchedules(for user: User, completion: @escaping (Result<[CKRecord], Error>) -> Void) {
        let predicate: NSPredicate
        switch user.role.rawValue {
        case "storeDirector":
            predicate = NSPredicate(value: true)
        case "etl":
            predicate = NSPredicate(format: "department IN %@", user.managedDepartments ?? [user.department])
        case "tl":
            predicate = NSPredicate(format: "department == %@", user.department)
        case "tm":
            predicate = NSPredicate(format: "employeeName == %@", user.username)
        default:
            predicate = NSPredicate(format: "employeeName == %@", user.username)
        }

        let query = CKQuery(recordType: "BreakSchedule", predicate: predicate)
        publicDB.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(records ?? []))
                }
            }
        }
    }

    // Fetch all schedules for a specific employeeName (username).
    func fetchSchedules(forUsername username: String, completion: @escaping (Result<[CKRecord], Error>) -> Void) {
        let predicate = NSPredicate(format: "employeeName == %@", username)
        let query = CKQuery(recordType: "BreakSchedule", predicate: predicate)

        publicDB.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(records ?? []))
                }
            }
        }
    }
    
    // Fetch schedules for a specific date (startTime within that day),
    // further filtered by the current user's role visibility.
    func fetchSchedules(for date: Date, user: User, completion: @escaping (Result<[CKRecord], Error>) -> Void) {
        let calendar = Calendar.current
        let startOfDay = calendar.startOfDay(for: date)
        let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay)!

        var predicates: [NSPredicate] = []

        // Time range predicate
        let datePredicate = NSPredicate(format: "startTime >= %@ AND startTime < %@", startOfDay as NSDate, endOfDay as NSDate)
        predicates.append(datePredicate)

        // Role-based filtering
        let rolePredicate: NSPredicate
        switch user.role.rawValue {
        case "storeDirector":
            rolePredicate = NSPredicate(value: true)
        case "etl":
            rolePredicate = NSPredicate(format: "department IN %@", user.managedDepartments ?? [user.department])
        case "tl":
            rolePredicate = NSPredicate(format: "department == %@", user.department)
        case "tm":
            rolePredicate = NSPredicate(format: "employeeName == %@", user.username)
        default:
            rolePredicate = NSPredicate(format: "employeeName == %@", user.username)
        }

        predicates.append(rolePredicate)

        let compoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: predicates)
        let query = CKQuery(recordType: "BreakSchedule", predicate: compoundPredicate)

        publicDB.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(records ?? []))
                }
            }
        }
    }

    
    // MARK: - PastSchedules (archive/previous)
    // Save a "past schedule" snapshot to CloudKit (no times—just descriptive fields).
    func savePastSchedule(_ schedule: Schedule, completion: @escaping (Result<Void, Error>) -> Void) {
        let record = CKRecord(recordType: "PastSchedules")
        record["name"] = schedule.name as CKRecordValue
        record["shift"] = schedule.shift as CKRecordValue
        record["firstBreak"] = schedule.firstBreak as CKRecordValue
        record["lunchBreak"] = schedule.lunchBreak as CKRecordValue
        record["secondBreak"] = schedule.secondBreak as CKRecordValue
        record["notes"] = schedule.notes.rawValue as CKRecordValue
        record["goals"] = schedule.goals as CKRecordValue

        publicDB.save(record) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(()))
                }
            }
        }
    }

    // Fetch all past schedules and convert each CKRecord → Schedule model.
    func fetchPastSchedules(completion: @escaping (Result<[Schedule], Error>) -> Void) {
        let query = CKQuery(recordType: "PastSchedules", predicate: NSPredicate(value: true))
        publicDB.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                    return
                }
                let schedules: [Schedule] = records?.compactMap { record in
                    let name = record["name"] as? String ?? "Unknown"
                    let shift = record["shift"] as? String ?? "Unknown"
                    let firstBreak = record["firstBreak"] as? String ?? ""
                    let lunchBreak = record["lunchBreak"] as? String ?? ""
                    let secondBreak = record["secondBreak"] as? String ?? ""
                    let notesRaw = record["notes"] as? String ?? "opu"
                    let notes = NoteType(rawValue: notesRaw) ?? .opu
                    let goals = record["goals"] as? String ?? ""
                    return Schedule(
                        id: UUID(),
                        employeeID: UUID(),
                        name: name,
                        shift: shift,
                        firstBreak: firstBreak,
                        lunchBreak: lunchBreak,
                        secondBreak: secondBreak,
                        notes: notes,
                        goals: goals
                    )
                } ?? []
                completion(.success(schedules))
            }
        }
    }

    // Delete a past schedule by matching name + shift.
    func deletePastSchedule(_ schedule: Schedule, completion: @escaping (Result<Void, Error>) -> Void) {
        let predicate = NSPredicate(format: "name == %@ AND shift == %@", schedule.name, schedule.shift)
        let query = CKQuery(recordType: "PastSchedules", predicate: predicate)

        self.publicDB.perform(query, inZoneWith: nil) { results, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let record = results?.first else {
                completion(.failure(NSError(domain: "", code: 404, userInfo: [NSLocalizedDescriptionKey: "No matching past schedule found."])))
                return
            }
            self.publicDB.delete(withRecordID: record.recordID) { _, deleteError in
                if let deleteError = deleteError {
                    completion(.failure(deleteError))
                } else {
                    completion(.success(()))
                }
            }
        }
    }
    
    // MARK: - Delete User Record
    // Delete a single User record by username (if found).
    func deleteUserRecord(username: String, completion: @escaping (Result<Void, Error>) -> Void) {
        print("deleteUserRecord CALLED for username: '\(username)'")

        let predicate = NSPredicate(format: "username == %@", username)
        let query = CKQuery(recordType: "User", predicate: predicate)

        publicDB.perform(query, inZoneWith: nil) { results, error in
            if let error = error {
                print("Error performing query: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }

            guard let record = results?.first else {
                print("No record found for username: \(username)")
                completion(.failure(NSError(domain: "", code: 404, userInfo: [NSLocalizedDescriptionKey: "User not found."])))
                return
            }

            print("Found record to delete: \(record.recordID.recordName) for \(username)")

            self.publicDB.delete(withRecordID: record.recordID) { _, deleteError in
                if let deleteError = deleteError {
                    print("Failed to delete record: \(deleteError.localizedDescription)")
                    completion(.failure(deleteError))
                } else {
                    print("Successfully deleted record: \(record.recordID.recordName)")
                    completion(.success(()))
                }
            }
        }
    }

    
    // MARK: - Delete Schedules
    // Delete all BreakSchedule rows for a given employeeName (username).
    func deleteSchedules(forUsername username: String, completion: @escaping (Result<Int, Error>) -> Void) {
        let predicate = NSPredicate(format: "employeeName == %@", username)
        let query = CKQuery(recordType: "BreakSchedule", predicate: predicate)

        publicDB.perform(query, inZoneWith: nil) { results, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let records = results, !records.isEmpty else {
                completion(.success(0)) // No schedules found
                return
            }

            let group = DispatchGroup()
            var deleteCount = 0
            var deleteError: Error?

            for record in records {
                group.enter()
                self.publicDB.delete(withRecordID: record.recordID) { _, error in
                    if let error = error {
                        deleteError = error
                    } else {
                        deleteCount += 1
                    }
                    group.leave()
                }
            }

            group.notify(queue: .main) {
                if let deleteError = deleteError {
                    completion(.failure(deleteError))
                } else {
                    completion(.success(deleteCount))
                }
            }
        }
    }
    
    // MARK: - Private BreakSchedule (per-user in Private DB)
    // Save a private BreakSchedule (stored in the user's Private DB).
    func savePrivateBreakSchedule(userID: String, date: Date, startTime: Date, endTime: Date, completion: @escaping (Result<Void, Error>) -> Void) {
        let record = CKRecord(recordType: "BreakSchedule")
        record["userID"] = userID as CKRecordValue
        record["date"] = date as CKRecordValue
        record["startTime"] = startTime as CKRecordValue
        record["endTime"] = endTime as CKRecordValue

        let privateDB = CKContainer.default().privateCloudDatabase
        privateDB.save(record) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(()))
                }
            }
        }
    }

    // Fetch today's private BreakSchedule rows for a specific userID.
    func fetchPrivateBreakSchedule(for userID: String, completion: @escaping (Result<[CKRecord], Error>) -> Void) {
        let privateDB = CKContainer.default().privateCloudDatabase
        let today = Calendar.current.startOfDay(for: Date())

        let predicate = NSPredicate(format: "userID == %@ AND date == %@", userID, today as CVarArg)
        let query = CKQuery(recordType: "BreakSchedule", predicate: predicate)

        privateDB.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(records ?? []))
                }
            }
        }
    }
    
    // Fetch an EmployeeShift (as a raw CKRecord) by UUID-based recordName.
    func fetchEmployeeShift(by id: UUID, completion: @escaping (Result<CKRecord, Error>) -> Void) {
        let recordID = CKRecord.ID(recordName: id.uuidString)

        CKContainer.default().publicCloudDatabase.fetch(withRecordID: recordID) { record, error in
            DispatchQueue.main.async {
                if let record = record {
                    completion(.success(record))
                } else {
                    completion(.failure(error ?? NSError(domain: "CloudKit", code: -1)))
                }
            }
        }
    }

    
    // MARK: - Fetch EmployeeShifts by username
    func fetchEmployeeShifts(forUsername username: String,
                             completion: @escaping (Result<[EmployeeShift], Error>) -> Void) {
        let predicate = NSPredicate(format: "employeeName == %@", username)
        let query = CKQuery(recordType: "BreakSchedule", predicate: predicate)

        publicDB.perform(query, inZoneWith: nil) { records, error in
            if let error = error {
                return DispatchQueue.main.async { completion(.failure(error)) }
            }

            let shifts: [EmployeeShift] = (records ?? []).compactMap { record in
                guard
                    let name = record["employeeName"] as? String,
                    let shiftStart = record["startTime"] as? Date,
                    let shiftEnd = record["endTime"] as? Date,
                    let dept = record["department"] as? String
                else { return nil }

                // Use stored strings as-is; do not try to coerce to UUIDs
                let employeeIDString = (record["employeeID"] as? String) ?? username
                let employeeCKID = CKRecord.ID(recordName: employeeIDString)

                return EmployeeShift(
                    id: record.recordID,
                    employeeID: employeeCKID,
                    name: name,
                    role: record["username"] as? String ?? "TM",
                    department: dept,
                    shiftStart: shiftStart,
                    shiftEnd: shiftEnd,
                    notes: record["notes"] as? String ?? "General",
                    goals: record["goals"] as? String ?? ""
                )
            }

            DispatchQueue.main.async { completion(.success(shifts)) }
        }
    }


    // MARK: - Coworkers (for swap picker, messaging, etc.)
    // Fetch all coworkers as Employee models (excluding a given record ID).
    func fetchEmployees(excluding userId: CKRecord.ID, completion: @escaping (Result<[Employee], Error>) -> Void) {
        let predicate = NSPredicate(value: true)
        let query = CKQuery(recordType: "User", predicate: predicate)
        
        let container = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule")
        print("Using CloudKit container: \(container.containerIdentifier ?? "default")")
        let publicDB = container.publicCloudDatabase

        publicDB.perform(query, inZoneWith: nil) { records, error in
            if let error = error {
                print("CloudKit query error: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            guard let records = records, !records.isEmpty else {
                print("No coworker records found")
                DispatchQueue.main.async {
                    completion(.success([]))
                }
                return
            }

            print("Coworker records retrieved: \(records.count)")

            let employees = records.compactMap { record -> Employee? in
                print("Inspecting record: \(record)")

                let recordId = record.recordID
                guard recordId != userId,
                      let name = record["username"] as? String,
                      let role = record["role"] as? String,
                      let dept = record["department"] as? String
                else {
                    print("Skipping invalid coworker record: \(record.recordID.recordName)")
                    return nil
                }

                return Employee(
                    id: record.recordID,
                    name: name,
                    role: role,
                    department: dept,
                    password: "",
                    needsPasswordChange: false,
                    managerUsername: ""
                )
            }

            print("Final coworker list: \(employees.map(\.name))")

            DispatchQueue.main.async {
                completion(.success(employees))
            }
        }
    }

    
    // MARK: - Save Shift Swap Request
    func saveShiftSwapRequest(_ swapRequest: ShiftSwapRequest, completion: @escaping (Result<Void, Error>) -> Void) {
        let record = swapRequest.toRecord()
        
        let privateDatabase = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase
        
        privateDatabase.save(record) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(()))
                }
            }
        }
    }

    // MARK: - Fetch Shift Swap Request
    func fetchShiftSwapRequests(completion: @escaping (Result<[ShiftSwapRequest], Error>) -> Void) {
        let predicate = NSPredicate(value: true) // no filter yet
        let query = CKQuery(recordType: "ShiftSwapRequest", predicate: predicate)
        let publicDatabase = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase
        
        publicDatabase.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    let swapRequests = records?.map { ShiftSwapRequest(record: $0) } ?? []
                    completion(.success(swapRequests))
                }
            }
        }
    }

    // MARK: - Update Swap Request Status
    func updateSwapRequestStatus(recordID: CKRecord.ID, newStatus: String, approvedBy: String? = nil, completion: @escaping (Result<Void, Error>) -> Void) {
        let privateDatabase = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase

        privateDatabase.fetch(withRecordID: recordID) { record, error in
            if let record = record, error == nil {
                // Update status and approver information
                record["status"] = newStatus as CKRecordValue
                
                if let approver = approvedBy {
                    record["approvedBy"] = approver as CKRecordValue
                }
                
                // Add the approval timestamp
                record["approvedAt"] = Date() as CKRecordValue
                
                privateDatabase.save(record) { _, saveError in
                    DispatchQueue.main.async {
                        if let saveError = saveError {
                            print("Failed to update swap request: \(saveError.localizedDescription)")
                            completion(.failure(saveError))
                        } else {
                            print("Swap request updated: Status - \(newStatus), Approved by - \(approvedBy ?? "N/A") at \(Date())")
                            completion(.success(()))
                        }
                    }
                }
            } else {
                DispatchQueue.main.async {
                    print("Error fetching swap request: \(error?.localizedDescription ?? "Unknown error")")
                    completion(.failure(error ?? NSError(domain: "ShiftSwap", code: -1)))
                }
            }
        }
    }
    
    // MARK: - Approve swap and exchange ownership of two BreakSchedule records atomically
    func approveSwapAndExchangeOwnership(
        swapRequestID: CKRecord.ID,
        approverUsername: String,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        let db = self.publicDB

        // Fetch the ShiftSwapRequest
        db.fetch(withRecordID: swapRequestID) { reqRecord, err in
            guard let req = reqRecord, err == nil else {
                return DispatchQueue.main.async {
                    completion(.failure(err ?? NSError(domain: "ShiftSwap", code: 404,
                                                       userInfo: [NSLocalizedDescriptionKey: "SwapRequest not found."])))
                }
            }

            // Accept "pending" or "PendingApproval"
            let status = (req["status"] as? String)?.lowercased() ?? "pending"
            if status != "pending" && status != "pendingapproval" {
                return DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "ShiftSwap", code: 409,
                                                userInfo: [NSLocalizedDescriptionKey: "SwapRequest is not pending."])))
                }
            }

            // Pull required fields from the request (your schema)
            guard
                let proposerShiftID = req["proposerShiftID"] as? String,
                let requestedShiftID = req["requestedShiftID"] as? String,
                let proposerEmployeeID = req["proposerEmployeeID"] as? String,
                let proposerEmployeeName = req["proposerEmployeeName"] as? String,
                let requestedEmployeeID = req["requestedEmployeeID"] as? String,
                let requestedEmployeeName = req["requestedEmployeeName"] as? String
            else {
                return DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "ShiftSwap", code: 422,
                                                userInfo: [NSLocalizedDescriptionKey: "SwapRequest missing required fields."])))
                }
            }

            let proposerShiftRecordID  = CKRecord.ID(recordName: proposerShiftID)
            let requestedShiftRecordID = CKRecord.ID(recordName: requestedShiftID)

            // Fetch both BreakSchedule records
            let group = DispatchGroup()
            var proposerShift: CKRecord?
            var requestedShift: CKRecord?
            var fetchError: Error?

            group.enter()
            db.fetch(withRecordID: proposerShiftRecordID) { rec, e in
                if let e = e { fetchError = e }
                proposerShift = rec
                group.leave()
            }

            group.enter()
            db.fetch(withRecordID: requestedShiftRecordID) { rec, e in
                if let e = e { fetchError = e }
                requestedShift = rec
                group.leave()
            }

            group.notify(queue: .global()) {
                if let e = fetchError {
                    return DispatchQueue.main.async { completion(.failure(e)) }
                }
                guard let prop = proposerShift, let reqs = requestedShift else {
                    return DispatchQueue.main.async {
                        completion(.failure(NSError(domain: "ShiftSwap", code: 404,
                                                    userInfo: [NSLocalizedDescriptionKey: "One or both BreakSchedule records not found."])))
                    }
                }

                // Sanity check existing owners
                let propOwnerID = (prop["employeeID"] as? String) ?? ""
                let reqOwnerID  = (reqs["employeeID"] as? String) ?? ""
                if propOwnerID != proposerEmployeeID || reqOwnerID != requestedEmployeeID {
                    print("Ownership mismatch pre-swap. Proceeding but logging.")
                }

                // Swap owners between the two shifts
                prop["employeeID"]   = requestedEmployeeID as CKRecordValue
                prop["employeeName"] = requestedEmployeeName as CKRecordValue

                reqs["employeeID"]   = proposerEmployeeID as CKRecordValue
                reqs["employeeName"] = proposerEmployeeName as CKRecordValue

                // Audit fields on shifts
                prop["lastModifiedAt"] = Date() as CKRecordValue
                prop["lastModifiedBy"] = approverUsername as CKRecordValue
                reqs["lastModifiedAt"] = Date() as CKRecordValue
                reqs["lastModifiedBy"] = approverUsername as CKRecordValue

                // Mark request approved + audit
                req["status"]     = "approved" as CKRecordValue
                req["approvedBy"] = approverUsername as CKRecordValue
                req["approvedAt"] = Date() as CKRecordValue

                // Save all three atomically
                let op = CKModifyRecordsOperation(recordsToSave: [prop, reqs, req], recordIDsToDelete: nil)
                op.savePolicy = .changedKeys
                op.isAtomic = true
                op.modifyRecordsResultBlock = { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success:
                            completion(.success(()))
                        case .failure(let error):
                            completion(.failure(error))
                        }
                    }
                }
                db.add(op)
            }
        }
    }

    
    // MARK: - Update Shift Owner
    func updateShiftOwner(shiftID: UUID, newOwnerID: UUID, newOwnerName: String, completion: @escaping (Result<Void, Error>) -> Void) {
        let recordID = CKRecord.ID(recordName: shiftID.uuidString)

        publicDB.fetch(withRecordID: recordID) { record, error in
            if let record = record, error == nil {
                record["employeeID"] = newOwnerID.uuidString as CKRecordValue
                record["employeeName"] = newOwnerName as CKRecordValue

                self.publicDB.save(record) { _, saveError in
                    DispatchQueue.main.async {
                        if let saveError = saveError {
                            print("Failed to update shift owner: \(saveError.localizedDescription)")
                            completion(.failure(saveError))
                        } else {
                            print("Shift owner updated to \(newOwnerName) [\(newOwnerID)]")
                            completion(.success(()))
                        }
                    }
                }
            } else {
                DispatchQueue.main.async {
                    print("Error fetching shift record: \(error?.localizedDescription ?? "Unknown error")")
                    completion(.failure(error ?? NSError(domain: "ShiftSwap", code: -1)))
                }
            }
        }
    }
    
    // MARK: - Save Message
    func saveMessage(_ message: Message, completion: @escaping (Bool) -> Void) {
        let record = CKRecord(recordType: "Message", recordID: message.id)

        let senderRef = CKRecord.Reference(recordID: message.sender.id, action: .none)
        let recipientRef = CKRecord.Reference(recordID: message.recipient.id, action: .none)

        record["sender"] = senderRef
        record["recipient"] = recipientRef
        record["content"] = message.content
        record["timestamp"] = message.timestamp

        // Debug check before save
        if record["recipient"] == nil {
            print("ERROR: recipient is nil – push notification won't fire.")
        } else {
            print("Message recipient set: \(message.recipient.id.recordName)")
        }

        publicDB.save(record) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("Failed to save message: \(error.localizedDescription)")
                    completion(false)
                } else {
                    print("Message successfully saved to CloudKit.")
                    self.fetchMessages(between: message.sender, and: message.recipient) { messages in
                        print("Fetched \(messages.count) messages between \(message.sender.id.recordName) and \(message.recipient.id.recordName)")
                    }

                    completion(true)
                }
            }
        }
    }

    
    // MARK: - Fetch Messages
    func fetchMessages(between user1: User, and user2: User, completion: @escaping ([Message]) -> Void) {
        print("Fetch Messages - Fetching messages between \(user1.id.recordName) and \(user2.id.recordName)")

        // Query 1: user1 → user2
        let senderToRecipientPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            NSPredicate(format: "sender == %@", CKRecord.Reference(recordID: user1.id, action: .none)),
            NSPredicate(format: "recipient == %@", CKRecord.Reference(recordID: user2.id, action: .none))
        ])

        // Query 2: user2 → user1
        let recipientToSenderPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            NSPredicate(format: "sender == %@", CKRecord.Reference(recordID: user2.id, action: .none)),
            NSPredicate(format: "recipient == %@", CKRecord.Reference(recordID: user1.id, action: .none))
        ])

        let query1 = CKQuery(recordType: "Message", predicate: senderToRecipientPredicate)
        let query2 = CKQuery(recordType: "Message", predicate: recipientToSenderPredicate)

        // Sort ascending by timestamp for both directions
        let sortDescriptor = NSSortDescriptor(key: "timestamp", ascending: true)
        query1.sortDescriptors = [sortDescriptor]
        query2.sortDescriptors = [sortDescriptor]

        var allMessages: [Message] = []
        let group = DispatchGroup()

        // Run both queries; combine results
        for query in [query1, query2] {
            group.enter()
            publicDB.perform(query, inZoneWith: nil) { records, error in
                if let error = error {
                    print("Error fetching messages: \(error.localizedDescription)")
                } else {
                    print("Fetched \(records?.count ?? 0) messages from one direction")
                }

                let messages: [Message] = records?.compactMap { record in
                    guard
                        let senderRef = record["sender"] as? CKRecord.Reference,
                        let recipientRef = record["recipient"] as? CKRecord.Reference,
                        let content = record["content"] as? String,
                        let timestamp = record["timestamp"] as? Date
                    else {
                        print("Skipping malformed message record.")
                        return nil
                    }

                    return Message(
                        id: record.recordID,
                        sender: User(id: senderRef.recordID, username: "", role: .tm, department: "", schedules: [], employees: []),
                        recipient: User(id: recipientRef.recordID, username: "", role: .tm, department: "", schedules: [], employees: []),
                        content: content,
                        timestamp: timestamp
                    )
                } ?? []

                allMessages.append(contentsOf: messages)
                group.leave()
            }
        }

        group.notify(queue: .main) {
            // Final merge-sort to ensure ascending order
            let sortedMessages = allMessages.sorted(by: { $0.timestamp < $1.timestamp })
            print("Total fetched messages: \(sortedMessages.count)")
            completion(sortedMessages)
        }
    }

    
    // MARK: - Subscribe To New Messages (visible alerts)
    func subscribeToNewMessages(for user: User, completion: @escaping (Result<Void, Error>) -> Void) {
        let recipientRef = CKRecord.Reference(recordID: user.id, action: .none)
        let predicate = NSPredicate(format: "recipient == %@", recipientRef)

        let subID = "incoming-messages-\(user.id.recordName)"
        let subscription = CKQuerySubscription(
            recordType: "Message",
            predicate: predicate,
            subscriptionID: subID,
            options: [.firesOnRecordCreation]
        )

        let info = CKSubscription.NotificationInfo()
        info.alertBody = "You’ve received a new message."
        info.soundName = "default"
        info.shouldBadge = true
        subscription.notificationInfo = info

        appLog("Creating message subscription id=\(subID), predicate=\(predicate)")

        publicDB.save(subscription) { _, error in
            DispatchQueue.main.async {
                if let ckErr = error as? CKError {
                    appLog("Message subscription error: \(ckErr) userInfo=\(ckErr.userInfo)")
                    if ckErr.code == .serverRejectedRequest {
                        appLog("Server says it already exists. Treating as success.")
                        completion(.success(()))
                    } else {
                        completion(.failure(ckErr))
                    }
                } else if let error = error {
                    appLog("Message subscription error: \(error.localizedDescription)")
                    completion(.failure(error))
                } else {
                    appLog("Message subscription created OK: \(subID)")
                    completion(.success(()))
                }
            }
        }
    }

    
    // MARK: - Subscribe To Swap Requests / Status Changes (visible alerts)
    func subscribeToSwapNotifications(for user: User, completion: @escaping (Result<Void, Error>) -> Void) {
        let db = publicDB
        let group = DispatchGroup()
        var firstError: Error?

        // Requests where this user is the requested coworker (new + updates)
        let requestedPredicate = NSPredicate(format: "requestedEmployeeID == %@", user.id.recordName)
        let requestedSub = CKQuerySubscription(
            recordType: "ShiftSwapRequest",
            predicate: requestedPredicate,
            subscriptionID: "swap-status-\(user.id.recordName)-requested",
            options: [.firesOnRecordCreation, .firesOnRecordUpdate]
        )
        let requestedInfo = CKSubscription.NotificationInfo()
        requestedInfo.alertBody = "Shift swap activity involving you."
        requestedInfo.soundName = "default"
        requestedInfo.shouldBadge = true
        requestedInfo.shouldSendContentAvailable = true
        requestedSub.notificationInfo = requestedInfo

        // Requests this user proposed (status updates only)
        let proposerPredicate = NSPredicate(format: "proposerEmployeeID == %@", user.id.recordName)
        let proposerSub = CKQuerySubscription(
            recordType: "ShiftSwapRequest",
            predicate: proposerPredicate,
            subscriptionID: "swap-status-\(user.id.recordName)-proposer",
            options: [.firesOnRecordUpdate]
        )
        let proposerInfo = CKSubscription.NotificationInfo()
        proposerInfo.alertBody = "Your shift swap request was updated."
        proposerInfo.soundName = "default"
        proposerInfo.shouldBadge = true
        proposerInfo.shouldSendContentAvailable = true
        proposerSub.notificationInfo = proposerInfo

        // Save both subscriptions. If they already exist, treat as success.
        for sub in [requestedSub, proposerSub] {
            group.enter()
            db.save(sub) { _, error in
                if let ckErr = error as? CKError, ckErr.code == .serverRejectedRequest {
                    print("Swap subscription already exists: \(sub.subscriptionID)")
                } else if let error = error {
                    print("Failed to save swap subscription \(sub.subscriptionID): \(error.localizedDescription)")
                    if firstError == nil { firstError = error }
                } else {
                    print("Created swap subscription: \(sub.subscriptionID)")
                }
                group.leave()
            }
        }

        group.notify(queue: .main) {
            if let error = firstError { completion(.failure(error)) }
            else { completion(.success(())) }
        }
    }

    // Audit current subscriptions and create any that are missing.
    // Writes simple logs of what exists vs. what will be created.
    func auditAndFixSubscriptions(for user: User, completion: (() -> Void)? = nil) {
        let db = self.publicDB
        db.fetchAllSubscriptions { subs, err in
            DispatchQueue.main.async {
                if let err = err {
                    appLog("fetchAllSubscriptions error: \(err.localizedDescription)")
                    completion?(); return
                }
                let subs = subs ?? []
                appLog("Found \(subs.count) PRODUCTION subscriptions in public DB.")
                for s in subs {
                    let info = (s.notificationInfo != nil) ? "hasInfo" : "noInfo"
                    appLog("\(s.subscriptionID) \(info)")
                }

                // IDs we expect to exist
                let msgID  = "incoming-messages-\(user.id.recordName)"
                let reqID  = "swap-status-\(user.id.recordName)-requested"
                let propID = "swap-status-\(user.id.recordName)-proposer"

                let haveMsg  = subs.contains { $0.subscriptionID == msgID }
                let haveReq  = subs.contains { $0.subscriptionID == reqID }
                let haveProp = subs.contains { $0.subscriptionID == propID }

                var toSave: [CKSubscription] = []

                // Create message subscription if missing
                if !haveMsg {
                    let rRef = CKRecord.Reference(recordID: user.id, action: .none)
                    let pred = NSPredicate(format: "recipient == %@", rRef)

                    let sub = CKQuerySubscription(recordType: "Message",
                                                  predicate: pred,
                                                  subscriptionID: msgID,
                                                  options: [.firesOnRecordCreation])

                    let info = CKSubscription.NotificationInfo()
                    info.title = "New Message"              // Title
                    info.alertBody = "You’ve received a new message." // Alert body
                    info.soundName = "default"
                    info.shouldBadge = true

                    sub.notificationInfo = info
                    toSave.append(sub)
                    appLog("Will create \(msgID)")
                }

                // Create "requested" swap sub if missing
                if !haveReq {
                    let pred = NSPredicate(format: "requestedEmployeeID == %@", user.id.recordName)
                    let sub  = CKQuerySubscription(recordType: "ShiftSwapRequest",
                                                   predicate: pred,
                                                   subscriptionID: reqID,
                                                   options: [.firesOnRecordCreation, .firesOnRecordUpdate])
                    let info = CKSubscription.NotificationInfo()
                    info.alertBody = "Shift swap activity involving you."
                    info.soundName = "default"
                    info.shouldBadge = true
                    info.shouldSendContentAvailable = true
                    sub.notificationInfo = info
                    toSave.append(sub)
                    appLog("Will create \(reqID)")
                }

                // Create "proposer" swap sub if missing
                if !haveProp {
                    let pred = NSPredicate(format: "proposerEmployeeID == %@", user.id.recordName)
                    let sub  = CKQuerySubscription(recordType: "ShiftSwapRequest",
                                                   predicate: pred,
                                                   subscriptionID: propID,
                                                   options: [.firesOnRecordUpdate])
                    let info = CKSubscription.NotificationInfo()
                    info.alertBody = "Your shift swap request was updated."
                    info.soundName = "default"
                    info.shouldBadge = true
                    info.shouldSendContentAvailable = true
                    sub.notificationInfo = info
                    toSave.append(sub)
                    appLog("Will create \(propID)")
                }

                guard !toSave.isEmpty else {
                    appLog("All required subs present.")
                    completion?(); return
                }

                // Save any missing subs in one operation
                let op = CKModifySubscriptionsOperation(subscriptionsToSave: toSave, subscriptionIDsToDelete: nil)
                op.modifySubscriptionsResultBlock = { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success:
                            appLog("Saved subs: \(toSave.map { $0.subscriptionID })")
                        case .failure(let e):
                            appLog("Failed to save subs: \(e.localizedDescription)")
                        }
                        completion?()
                    }
                }
                db.add(op)
            }
        }
    }
    
    // Save a self-addressed Message for the given user to test pushes.
    func sendTestCloudKitMessage(to user: User) {
        let record = CKRecord(recordType: "Message")
        let senderRef = CKRecord.Reference(recordID: user.id, action: .none)
        let recipientRef = CKRecord.Reference(recordID: user.id, action: .none)

        record["sender"] = senderRef
        record["recipient"] = recipientRef
        record["content"] = "Test CloudKit push at \(Date())"
        record["timestamp"] = Date()

        appLog("Saving test Message for \(user.id.recordName) to trigger CK push...")
        publicDB.save(record) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    appLog("Test message save failed: \(error)")
                } else {
                    appLog("Test message saved. If subscription exists, a push should arrive.")
                }
            }
        }
    }

}

