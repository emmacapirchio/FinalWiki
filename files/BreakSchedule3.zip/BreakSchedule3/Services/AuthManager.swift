//
//  AuthManager.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 3/6/25.
//
//  Purpose:
//  - Handle user authentication and user CRUD against CloudKit.
//
//  Notes:
//  - Passwords are never stored in plain text, they’re hashed with SHA-256.
//  - Uses CloudKit public database inside the iCloud.com.ecapirchio.BreakSchedule container.
//  - Many calls hand off to CloudKitManager for record saving and fetching.
//

import CloudKit
import CryptoKit
import AuthenticationServices

class AuthManager {
    // Singleton instance for global access
    static let shared = AuthManager()
    
    // Public DB for this app’s container
    private let database = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase
    
    // MARK: - Hash Password
    // Hashes a plain text password with SHA-256 and returns the hex string.
    func hashPassword(_ password: String) -> String {
        let data = Data(password.utf8)
        let hashed = SHA256.hash(data: data)
        return hashed.compactMap { String(format: "%02x", $0) }.joined()
    }


    // MARK: Change Password
    // Finds a user record by username and updates its stored password hash.
    func changePassword(username: String, newPassword: String, completion: @escaping (Result<String, Error>) -> Void) {
        let predicate = NSPredicate(format: "username == %@", username)
        let query = CKQuery(recordType: "User", predicate: predicate)
        
        database.perform(query, inZoneWith: nil) { results, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let userRecord = results?.first else {
                completion(.failure(NSError(domain: "User not found", code: 404, userInfo: nil)))
                return
            }
            
            // Hash the new password
            let hashedPassword = self.hashPassword(newPassword)
            userRecord["passwordHash"] = hashedPassword as CKRecordValue
            
            self.database.save(userRecord) { _, saveError in
                if let saveError = saveError {
                    completion(.failure(saveError))
                } else {
                    completion(.success("Password changed successfully!"))
                }
            }
        }
    }
    
    // MARK: - Fetch User Data
    // Loads a user by username using the shared CloudKitManager.
    func fetchUser(username: String, completion: @escaping (Result<User, Error>) -> Void) {
        CloudKitManager.shared.fetchUser(username: username, completion: completion)
    }

    
    // MARK: - Sign in with Apple
    // Signs in with Apple, returning an existing user or creating a new one.
    func logInWithApple(authResults: ASAuthorization, completion: @escaping (User) -> Void) {
        guard let credential = authResults.credential as? ASAuthorizationAppleIDCredential else {
            print("Error: Unable to retrieve Apple ID credentials")
            return
        }

        let userId = credential.user
        let username = credential.fullName?.givenName ?? "User"
        let recordID = CKRecord.ID(recordName: userId)

        // Look for an existing CloudKit record for this Apple ID
        CloudKitManager.shared.fetchRecord(withID: recordID) { record, error in
            DispatchQueue.main.async {
                if let record = record {
                    // Existing user: rebuild a User model from the record
                    let department = record["department"] as? String ?? "Unknown"
                    let role = record["role"] as? String ?? "user"
                    var schedules: [[Schedule]] = []
                    var employees: [Employee] = []

                    if let schedulesData = record["schedules"] as? Data {
                        schedules = (try? JSONDecoder().decode([[Schedule]].self, from: schedulesData)) ?? []
                    }
                    if let employeesData = record["employees"] as? Data {
                        employees = (try? JSONDecoder().decode([Employee].self, from: employeesData)) ?? []
                    }

                    let idString = record.recordID.recordName
                    let uuid = UUID(uuidString: idString) ?? UUID()

                    let user = User(
                        id: recordID,
                        employeeID: uuid,
                        username: credential.email ?? username,
                        role: EmployeeRole(rawValue: role) ?? .tm,
                        department: department,
                        schedules: schedules,
                        employees: employees
                    )

                    completion(user)
                } else {
                    // No existing record → register a new Apple user
                    self.registerNewAppleUser(userId: userId, username: username, completion: completion)
                }
            }
        }
    }
    
    // Creates a new CloudKit User record for a first-time Apple sign-in.
    private func registerNewAppleUser(userId: String, username: String, completion: @escaping (User) -> Void) {
        let department = "Unknown"
        let role = "user"
        let schedules: [[Schedule]] = []
        let employees: [Employee] = []

        let record = CKRecord(recordType: "User", recordID: CKRecord.ID(recordName: userId))
        record["username"] = username as CKRecordValue
        record["department"] = department as CKRecordValue
        record["role"] = role as CKRecordValue
        record["schedules"] = try? JSONEncoder().encode(schedules) as CKRecordValue?
        record["employees"] = try? JSONEncoder().encode(employees) as CKRecordValue?

        CloudKitManager.shared.saveRecord(record) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("Error registering Apple user: \(error.localizedDescription)")
                    return
                }
                let recordID = record.recordID
                let uuid = UUID(uuidString: userId) ?? UUID()

                let user = User(
                    id: recordID,
                    employeeID: uuid,
                    username: username,
                    role: EmployeeRole(rawValue: role) ?? .tm,
                    department: department,
                    managedDepartments: nil,
                    schedules: schedules,
                    employees: employees
                )

                completion(user)
            }
        }
    }
    
    // MARK: - Username/Password Registration
    // Creates a new CloudKit user with a hashed password after checking for duplicates.
    func registerUser(username: String, password: String, department: String, completion: @escaping (Result<Void, Error>) -> Void) {
        // Fetch all users to check for duplicates
        CloudKitManager.shared.fetchAllUsers { users in
            // Check if any user already has the same username
            if users.contains(where: { $0.username == username }) {
                // Username already exists
                let error = NSError(domain: "RegistrationError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Username already taken. Try another username"])
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }
            
            // Create a new user record since no duplicates were found
            let record = CKRecord(recordType: "User")
            record["username"] = username as CKRecordValue
            record["department"] = department as CKRecordValue
            record["role"] = EmployeeRole.tm.rawValue as CKRecordValue // Default role is Team Member
            
            // Hash the password before storing
            let hashedPassword = self.hashPassword(password)
            record["passwordHash"] = hashedPassword as CKRecordValue

            // Save the new user record to CloudKit
            CloudKitManager.shared.saveRecord(record) { savedRecord, error in
                DispatchQueue.main.async {
                    if let error = error {
                        completion(.failure(error))
                    } else {
                        completion(.success(()))
                    }
                }
            }
        }
    }



    // MARK: - Username/Password Login
    // Validates a username/password by comparing stored and entered hashes, then fetches the full User object from CloudKit.
    func loginUser(username: String, password: String, completion: @escaping (Result<User, Error>) -> Void) {
        let predicate = NSPredicate(format: "username == %@", username)
        let query = CKQuery(recordType: "User", predicate: predicate)
        
        database.perform(query, inZoneWith: nil) { results, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let userRecord = results?.first else {
                completion(.failure(NSError(domain: "AuthError", code: 404, userInfo: [NSLocalizedDescriptionKey: "User not found"])))
                return
            }
            
            guard let storedHash = userRecord["passwordHash"] as? String else {
                completion(.failure(NSError(domain: "AuthError", code: 400, userInfo: [NSLocalizedDescriptionKey: "Password hash missing for user"])))
                return
            }
            
            let enteredHash = self.hashPassword(password)
            
            // Compare entered password hash with stored hash
            guard storedHash == enteredHash else {
                completion(.failure(NSError(domain: "AuthError", code: 401, userInfo: [NSLocalizedDescriptionKey: "Invalid password"])))
                return
            }
            
            // Password is valid, now fetch full user object
            self.fetchUser(username: username) { result in
                completion(result)
            }
        }
    }

    // MARK: - Load User
    // Loads an existing CloudKit user and prints result for debugging.
    func loadUser(username: String, completion: @escaping (Result<User, Error>) -> Void) {
        CloudKitManager.shared.fetchUser(username: username) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    print("User loaded: \(user.username), Role: \(user.role)")
                    completion(.success(user))
                case .failure(let error):
                    print("Failed to load user: \(error.localizedDescription)")
                    completion(.failure(error))
                }
            }
        }
    }
    
    // MARK: - Create User (utility)
    // Creates a user directly (useful for seeding or admin tools).
    func createUser(username: String, role: String = "user", department: String = "General", password: String = "Password1", completion: @escaping (Result<Void, Error>) -> Void) {
        let database = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase
        let hashedPassword = self.hashPassword(password)

        let newUser = CKRecord(recordType: "User")
        newUser["username"] = username as CKRecordValue
        newUser["role"] = role as CKRecordValue
        newUser["department"] = department as CKRecordValue
        newUser["passwordHash"] = hashedPassword as CKRecordValue
        newUser["createdAt"] = Date() as CKRecordValue

        database.save(newUser) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(()))
                }
            }
        }
    }

    // MARK: - Debug Helper
    // Prints the hash of a given password (used during migration or testing).
    func printHashedPassword(_ password: String) {
        let hashed = hashPassword(password)
        print("Hashed password for '\(password)' is: \(hashed)")
    }
}
