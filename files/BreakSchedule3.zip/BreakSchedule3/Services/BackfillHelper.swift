//
//  BackfillHelper.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 4/28/25.
//
//  Purpose:
//  - One-time utility to backfill missing `employeeID` fields
//    on BreakSchedule records in CloudKit. Uses a consistent mapping:
//    all rows with the same `employeeName` get the same generated UUID.
//
//  Notes:
//  - This runs against the Public DB of the iCloud container.
//  - Safe to re-run: records that already have `employeeID` are skipped.
//  - We only update records missing `employeeID`; others are untouched.
//


import CloudKit
import Foundation

struct BackfillHelper {
    
    // Scans BreakSchedule records and assigns a UUID to any row missing `employeeID`.
    // Rows sharing the same `employeeName` in this run receive the same UUID,
    // ensuring consistency across multiple records for the same person.
    static func backfillEmployeeIDs(completion: @escaping (Result<Void, Error>) -> Void) {
        let container = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule")
        let publicDB = container.publicCloudDatabase
        let query = CKQuery(recordType: "BreakSchedule", predicate: NSPredicate(value: true)) // fetch all

        publicDB.perform(query, inZoneWith: nil) { records, error in
            // Network/CloudKit error handling
            if let error = error {
                print("Error fetching records: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            // No records found—consider this a no-op result.
            guard let records = records else {
                print("No records found.")
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "NoRecords", code: 0, userInfo: nil)))
                }
                return
            }

            var recordsToUpdate: [CKRecord] = []
            
            // Maintains a consistent in-memory mapping for this run:
            // same employeeName → same assigned UUID.
            var employeeNameToUUID: [String: UUID] = [:] // employeeName → employeeID map

            // Iterate all records; only touch those missing `employeeID`.
            for record in records {
                if record["employeeID"] == nil {
                    print("Missing employeeID for record: \(record.recordID.recordName)")

                    // We require employeeName to generate a stable mapping.
                    if let employeeName = record["employeeName"] as? String {
                        
                        // Reuse the same UUID if we've seen this name already.
                        let assignedUUID: UUID

                        if let existingUUID = employeeNameToUUID[employeeName] {
                            assignedUUID = existingUUID
                        } else {
                            assignedUUID = UUID()
                            employeeNameToUUID[employeeName] = assignedUUID
                        }

                        // Save the generated UUID (as a String) back to the record.
                        record["employeeID"] = assignedUUID.uuidString as CKRecordValue
                        print("Assigned consistent employeeID: \(assignedUUID) to employeeName: \(employeeName)")
                        recordsToUpdate.append(record)
                    } else {
                        // If there’s no name, we can’t derive a consistent mapping.
                        print("Skipped record — no employeeName to generate consistent employeeID.")
                    }
                }
            }

            // Nothing to update → succeed early.
            if recordsToUpdate.isEmpty {
                print("No missing employeeIDs found. No backfill needed.")
                DispatchQueue.main.async {
                    completion(.success(()))
                }
                return
            }

            // Batch-save all updated records in one modify operation.
            let modifyOperation = CKModifyRecordsOperation(recordsToSave: recordsToUpdate, recordIDsToDelete: nil)
            
            // Completion block reports success/failure for the whole batch.
            modifyOperation.modifyRecordsCompletionBlock = { savedRecords, _, error in
                if let error = error {
                    print("Error saving updated records: \(error.localizedDescription)")
                    DispatchQueue.main.async {
                        completion(.failure(error))
                    }
                    return
                }

                print("Successfully updated \(savedRecords?.count ?? 0) records!")
                DispatchQueue.main.async {
                    completion(.success(()))
                }
            }

            publicDB.add(modifyOperation)
        }
    }
}


