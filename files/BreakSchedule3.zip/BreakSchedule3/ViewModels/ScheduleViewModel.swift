//
//  ScheduleViewModel.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 12/1/24.
//
//  Purpose:
//  - Central state holder for login, employees, shift generation,
//    schedule CRUD, CloudKit interactions, and push subscription wiring.
//
//  Notes:
//   - Publishes UI-facing state for SwiftUI views.
//   - Delegates CloudKit work to CloudKitManager.
//   - Persists minimal state (logged in user id, users cache) to UserDefaults.
//

import Foundation
import PDFKit
import UIKit
import CloudKit
import AuthenticationServices

class ScheduleViewModel: ObservableObject {
    @Published var showChangePasswordView: Bool = false
    @Published var useNeonTheme: Bool = false
    @Published var selectedEmployees: [EmployeeShift] = [] // Employees selected for scheduling
    @Published var shifts: [EmployeeShift] = [] // Employee shifts with start and end times
    @Published var schedule: [Schedule] = [] // Current schedule
    @Published var users: [User] = [] // All registered users
    @Published var allEmployees: [Employee] = [] // Stores all employees for admins
    @Published var loggedInUser: User? { // Update the user state dynamically
        didSet { updateUserData() }
    }

    // Keeps our CloudKit push observer so we can remove it on logout
    private var cloudKitPushObserver: NSObjectProtocol?

    var pastSchedules: [[Schedule]] {
        loggedInUser?.schedules ?? []
    }
    var employees: [Employee] {
        loggedInUser?.employees ?? []
    }

    init() {
        loadUsers()
    }

    // MARK: - Auth
    // Handles sign in with Apple -> sets loggedInUser, requests notifications, and sets up CK subscriptions
    func logInWithApple(authResults: ASAuthorization, completion: @escaping (Bool, String?) -> Void) {
        AuthManager.shared.logInWithApple(authResults: authResults) { user in
            DispatchQueue.main.async {
                self.loggedInUser = user
                UserDefaults.standard.set(user.id.recordName, forKey: "loggedInUserID")

                NotificationHelper.requestIfNeeded { granted in
                    if granted { self.setUpCloudKitSubscriptions(for: user) }
                }
                completion(true, nil)
            }
        }
    }

    // Username/password login -> validates, stores user id locally, and sets up pushes
    func loginUser(username: String, password: String, completion: @escaping (Bool, String?) -> Void) {
        AuthManager.shared.loginUser(username: username, password: password) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    self.loggedInUser = user
                    UserDefaults.standard.set(user.id.recordName, forKey: "loggedInUserID")

                    NotificationHelper.requestIfNeeded { granted in
                        if granted { self.setUpCloudKitSubscriptions(for: user) }
                    }

                    if let me = user.employees.first(where: { $0.name == username }),
                       me.needsPasswordChange {
                        self.showChangePasswordView = true
                    }

                case .failure(let error):
                    print("Login failed: \(error.localizedDescription)")
                    completion(false, "Wrong username or password")
                }
            }
        }
    }


    // Clears logged-in state and removes any push observers
    func logOut() {
        loggedInUser = nil
        UserDefaults.standard.removeObject(forKey: "loggedInUserID")

        if let obs = cloudKitPushObserver {
            NotificationCenter.default.removeObserver(obs)
            cloudKitPushObserver = nil
        }
    }

    // Loads a user by username and sets up notifications/subs if allowed
    private func loadUser(username: String) {
        AuthManager.shared.loadUser(username: username) { result in
            switch result {
            case .success(let user):
                DispatchQueue.main.async {
                    self.loggedInUser = user
                    UserDefaults.standard.set(user.id.recordName, forKey: "loggedInUserID")
                    print("Logged in as \(user.username)")
                    // Subscriptions + push observer
                    print("USER - Attempting to subscribe for messages & swaps for: \(user.username)")
                    NotificationHelper.requestIfNeeded { granted in
                        guard granted else { return }
                        self.setUpCloudKitSubscriptions(for: user)
                    }
                }
            case .failure(let error):
                print("Could not load user: \(error.localizedDescription)")
            }
        }
    }

    // Loads all users and attempts session restore based on saved recordName
    func loadUsers() {
        CloudKitManager.shared.fetchAllUsers { users in
            self.users = users
            print("Loaded \(users.count) users from CloudKit")

            if let savedId = UserDefaults.standard.string(forKey: "loggedInUserID"),
               let restored = users.first(where: { $0.id.recordName == savedId }) {
                self.loggedInUser = restored
                // User may have previously granted notifications; ensure subs exist:
                self.setUpCloudKitSubscriptions(for: restored)
            } else {
                print("No logged-in user – will subscribe later.")
            }
        }
    }

    // Persists the logged-in user's embedded employees/schedules arrays back to CloudKit
    func saveLoggedInUserChanges() {
        guard let user = loggedInUser else { return }

        let recordID = CKRecord.ID(recordName: user.id.recordName)
        let database = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase

        database.fetch(withRecordID: recordID) { record, error in
            DispatchQueue.main.async {
                guard let record = record, error == nil else {
                    print("Error fetching user record for update: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }

                do {
                    let employeesData = try JSONEncoder().encode(user.employees)
                    let schedulesData = try JSONEncoder().encode(user.schedules)

                    record["employees"] = employeesData as CKRecordValue
                    record["schedules"] = schedulesData as CKRecordValue

                    database.save(record) { _, saveError in
                        DispatchQueue.main.async {
                            if let saveError = saveError {
                                print("Error saving user: \(saveError.localizedDescription)")
                            } else {
                                print("User changes saved to CloudKit")
                            }
                        }
                    }
                } catch {
                    print("Failed to encode user data: \(error.localizedDescription)")
                }
            }
        }
    }

    // MARK: - Employee Management
    // Removes an employee from the logged-in user's local list and persists change
    func deleteEmployee(_ employee: Employee) {
        guard var currentEmployees = loggedInUser?.employees else { return }
        currentEmployees.removeAll(where: { $0.id == employee.id })
        loggedInUser?.employees = currentEmployees
        saveLoggedInUserChanges()
    }

    // Updates employee fields in CloudKit and mirrors the change locally
    func updateEmployee(employee: Employee, newName: String, newRole: String, newDepartment: String, needsPasswordChange: Bool = false) {
        guard loggedInUser?.role == .storeDirector else {
            print("Only store directors can edit employees.")
            return
        }
        let recordID = CKRecord.ID(recordName: employee.id.recordName)
        let database = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase

        database.fetch(withRecordID: recordID) { record, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("Error fetching employee record: \(error.localizedDescription)")
                    return
                }

                guard let record = record else {
                    print("No matching employee record found.")
                    return
                }

                record["username"] = newName as CKRecordValue
                record["role"] = newRole as CKRecordValue
                record["department"] = newDepartment as CKRecordValue
                record["needsPasswordChange"] = needsPasswordChange as CKRecordValue

                database.save(record) { _, saveError in
                    DispatchQueue.main.async {
                        if let saveError = saveError {
                            print("Error updating employee: \(saveError.localizedDescription)")
                            return
                        }

                        print("Employee updated: \(newName), Role: \(newRole)")

                        if let index = self.loggedInUser?.employees.firstIndex(where: { $0.id == employee.id }) {
                            self.loggedInUser?.employees[index] = Employee(
                                id: employee.id,
                                name: newName,
                                role: newRole,
                                department: newDepartment,
                                needsPasswordChange: false
                            )
                            self.saveLoggedInUserChanges()
                        }
                    }
                }
            }
        }
    }
    
    // Pulls all employees from CloudKit, then filters them according to the current user's role
    func fetchAllEmployees() {
        CloudKitManager.shared.fetchAllEmployees { allEmployees in
            let filtered = self.filterEmployeesForCurrentUser(allEmployees)
            self.loggedInUser?.employees = filtered
        }
    }

    // Simple role-based visibility filter (SD > ETL > TL > TM)
    func filterEmployeesForCurrentUser(_ employees: [Employee]) -> [Employee] {
        guard let user = loggedInUser else { return [] }

        switch user.role {
        case .storeDirector:
            return employees
        case .etl:
            return employees.filter { $0.role.lowercased() == "tl" || $0.role.lowercased() == "tm" }
        case .tl:
            return employees.filter {
                $0.role.lowercased() == "tm" && $0.department.lowercased() == user.department.lowercased()
            }
        case .tm:
            return employees.filter { $0.id == user.id }
        }
    }

    // Reorders employees locally and persists inside the logged-in user payload
    func moveEmployee(from source: IndexSet, to destination: Int) {
        guard var employees = loggedInUser?.employees else { return }
        employees.move(fromOffsets: source, toOffset: destination)
        loggedInUser?.employees = employees
        saveLoggedInUserChanges()
        print("Moved employee(s) and saved new order")
    }

    // MARK: - Schedule Management
    // Creates Schedule rows from EmployeeShift inputs with simple break-spacing logic
    private func generateScheduleItems(from employees: [EmployeeShift]) -> [Schedule] {
        var occupiedBreaks: Set<String> = [] // helps avoid overlapping break times (by "HH:mm" string)

        // Finds the next 15-min slot not already taken in occupiedBreaks
        func findNextAvailableTime(proposedTime: Date) -> Date {
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm"
            var time = proposedTime
            while occupiedBreaks.contains(formatter.string(from: time)) {
                time.addTimeInterval(15 * 60)
            }
            occupiedBreaks.insert(formatter.string(from: time))
            return time
        }

        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"

        // Sort by shiftStart, then map each EmployeeShift -> Schedule
        return employees.sorted {
            guard let s1 = $0.shiftStart, let s2 = $1.shiftStart else {
                return $0.shiftStart != nil
            }
            return s1 < s2
        }.map { employee in
            guard let shiftStart = employee.shiftStart, let shiftEnd = employee.shiftEnd else {
                print("Missing shift times for employee: \(employee.name)")
                return Schedule(
                    employeeID: UUID(uuidString: employee.employeeID.recordName) ?? UUID(),
                    name: employee.name,
                    shift: "Shift time missing",
                    firstBreak: "",
                    lunchBreak: "",
                    secondBreak: "",
                    notes: NoteType(rawValue: employee.notes) ?? .opu,
                    goals: employee.goals,
                    shiftStart: Date(),
                    shiftEnd: Date()
                )
            }

            let duration = shiftEnd.timeIntervalSince(shiftStart) / 3600

            var firstBreak: Date? = nil
            var lunchBreak: Date? = nil
            var secondBreak: Date? = nil

            // Very simple spacing: first at +2h, lunch at +5h, second at +7h if long enough
            if duration > 4 { firstBreak = findNextAvailableTime(proposedTime: shiftStart.addingTimeInterval(2 * 3600)) }
            if duration > 6 { lunchBreak = findNextAvailableTime(proposedTime: shiftStart.addingTimeInterval(5 * 3600)) }
            if duration > 8 { secondBreak = findNextAvailableTime(proposedTime: shiftStart.addingTimeInterval(7 * 3600)) }

            return Schedule(
                employeeID: UUID(uuidString: employee.employeeID.recordName) ?? UUID(),
                name: employee.name,
                shift: "\(formatter.string(from: shiftStart)) - \(formatter.string(from: shiftEnd))",
                firstBreak: firstBreak.map { formatter.string(from: $0) } ?? "",
                lunchBreak: lunchBreak.map { formatter.string(from: $0) } ?? "",
                secondBreak: secondBreak.map { formatter.string(from: $0) } ?? "",
                notes: NoteType(rawValue: employee.notes) ?? .opu,
                goals: employee.goals,
                shiftStart: shiftStart,
                shiftEnd: shiftEnd
            )
        }
    }

    // Generates schedules from selected employees and saves each row to CloudKit
    func generateAndSaveSchedule() {
        guard let user = loggedInUser else {
            print("No logged-in user.")
            return
        }

        // Only store directors are allowed to generate schedules
        if user.role != .storeDirector {
            print("Only store directors can generate schedules.")
            return
        }

        guard !selectedEmployees.isEmpty else {
            print("No employees selected.")
            return
        }

        // Use any edits in `shifts` to update `selectedEmployees` before generating
        for i in 0..<selectedEmployees.count {
            if let updated = shifts.first(where: { $0.id == selectedEmployees[i].id }) {
                selectedEmployees[i] = updated
            }
        }

        // Create the schedule rows and reflect them in the UI
        let generatedSchedules = generateScheduleItems(from: selectedEmployees)
        schedule = generatedSchedules

        let dispatchGroup = DispatchGroup()

        // Save each schedule row to CloudKit
        for scheduleItem in generatedSchedules {
            dispatchGroup.enter()
            CloudKitManager.shared.saveSchedule(scheduleItem, department: user.department) { result in
                switch result {
                case .success:
                    self.saveToPastSchedules(schedule: scheduleItem)
                    print("Schedule saved for \(scheduleItem.name)")
                case .failure(let error):
                    print("Failed to save schedule for \(scheduleItem.name): \(error.localizedDescription)")
                }
                dispatchGroup.leave()
            }
        }

        // Once all saves finish, pull fresh data from CloudKit
        dispatchGroup.notify(queue: .main) {
            print("All schedules saved — now fetching from CloudKit...")
            self.fetchCurrentSchedules()
        }
    }

    // Fetches all schedules visible to the current user (role-based)
    func fetchCurrentSchedules() {
        guard let user = loggedInUser else { return }

        CloudKitManager.shared.fetchSchedules(for: user) { result in
            switch result {
            case .success(let records):
                // Convert CKRecords -> Schedule models
                let fetchedSchedules: [Schedule] = records.compactMap { record in
                    let employeeIDString = record["employeeID"] as? String ?? ""
                    let employeeID = UUID(uuidString: employeeIDString) ?? UUID()
                    // keep parsing other fields; only bail if those are really missing
                    guard let name = record["employeeName"] as? String,
                          let shiftStart = record["startTime"] as? Date,
                          let shiftEnd = record["endTime"] as? Date,
                          let firstBreak = record["firstBreak"] as? String,
                          let lunchBreak = record["lunchBreak"] as? String,
                          let secondBreak = record["secondBreak"] as? String,
                          let notesRaw = record["notes"] as? String,
                          let goals = record["goals"] as? String
                    else { return nil }


                    let formatter = DateFormatter()
                    formatter.timeStyle = .short

                    let shiftString = "\(formatter.string(from: shiftStart)) - \(formatter.string(from: shiftEnd))"
                    let notes = NoteType(rawValue: notesRaw) ?? .general

                    return Schedule(
                        employeeID: employeeID,
                        name: name,
                        shift: shiftString,
                        firstBreak: firstBreak,
                        lunchBreak: lunchBreak,
                        secondBreak: secondBreak,
                        notes: notes,
                        goals: goals,
                        date: Date(),
                        shiftStart: shiftStart,
                        shiftEnd: shiftEnd
                    )
                }

                DispatchQueue.main.async {
                    self.schedule = fetchedSchedules
                    print("Updated UI with \(fetchedSchedules.count) schedules.")
                }

            case .failure(let error):
                print("Failed to fetch schedules: \(error.localizedDescription)")
            }
        }
    }

    // Deletes a single schedule both in CloudKit and locally
    func deleteScheduleFromCloudKit(_ scheduleToDelete: Schedule) {
        CloudKitManager.shared.deleteSchedule(scheduleToDelete) { result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    print("Schedule deleted from CloudKit.")
                    if let index = self.schedule.firstIndex(where: { $0.id == scheduleToDelete.id }) {
                        self.schedule.remove(at: index)
                    }
                case .failure(let error):
                    print("Failed to delete schedule: \(error.localizedDescription)")
                }
            }
        }
    }

    // Convenience wrapper to fetch schedules and hand raw records back to a caller
    func fetchBreakSchedules(completion: @escaping ([CKRecord]?) -> Void) {
        guard let user = loggedInUser else { return }

        CloudKitManager.shared.fetchSchedules(for: user) { result in
            switch result {
            case .success(let records):
                completion(records)
            case .failure(let error):
                print("Failed to fetch schedules: \(error.localizedDescription)")
                completion(nil)
            }
        }
    }

    // Pulls only the logged-in user's schedules by username
    func fetchUserSchedule() {
        guard let username = loggedInUser?.username else {
            print("No logged-in user.")
            return
        }

        CloudKitManager.shared.fetchSchedules(forUsername: username) { result in
            switch result {
            case .success(let records):
                print("Fetched \(records.count) schedules for \(username)")

                let decodedSchedules: [Schedule] = records.compactMap { record in
                    guard let name = record["employeeName"] as? String,
                          let shiftStart = record["startTime"] as? Date,
                          let shiftEnd = record["endTime"] as? Date else { return nil }

                    let shiftString = "\(shiftStart) - \(shiftEnd)"

                    let firstBreak = record["firstBreak"] as? String ?? ""
                    let lunchBreak = record["lunchBreak"] as? String ?? ""
                    let secondBreak = record["secondBreak"] as? String ?? ""
                    let notesRaw = record["notes"] as? String ?? "opu"
                    let goals = record["goals"] as? String ?? ""

                    return Schedule(
                        name: name,
                        shift: shiftString,
                        firstBreak: firstBreak,
                        lunchBreak: lunchBreak,
                        secondBreak: secondBreak,
                        notes: NoteType(rawValue: notesRaw) ?? .opu,
                        goals: goals,
                        date: record.creationDate ?? Date(),
                        shiftStart: shiftStart,
                        shiftEnd: shiftEnd
                    )
                }

                self.schedule = decodedSchedules

            case .failure(let error):
                print("Failed to fetch user schedule: \(error.localizedDescription)")
            }
        }
    }

    // MARK: - Past Schedule Management
    // Writes a snapshot of a schedule to the "PastSchedules" record type
    func saveToPastSchedules(schedule: Schedule) {
        CloudKitManager.shared.savePastSchedule(schedule) { result in
            switch result {
            case .success:
                print("Past schedule saved for \(schedule.name)")
            case .failure(let error):
                print("Error saving past schedule: \(error.localizedDescription)")
            }
        }
    }

    // Loads past schedules and stores them under loggedInUser.schedules as a single group
    func fetchPastSchedules() {
        CloudKitManager.shared.fetchPastSchedules { result in
            switch result {
            case .success(let schedules):
                print("Loaded \(schedules.count) past schedules.")
                self.loggedInUser?.schedules = [schedules]
            case .failure(let error):
                print("Error fetching past schedules: \(error.localizedDescription)")
            }
        }
    }

    // Deletes a past schedule from CloudKit and removes it from the local grouped array
    func deletePastSchedule(schedule: Schedule) {
        CloudKitManager.shared.deletePastSchedule(schedule) { result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    print("Past schedule deleted from CloudKit.")
                    if var scheduleGroups = self.loggedInUser?.schedules {
                        for i in scheduleGroups.indices {
                            if let matchIndex = scheduleGroups[i].firstIndex(where: { $0.id == schedule.id }) {
                                scheduleGroups[i].remove(at: matchIndex)
                                if scheduleGroups[i].isEmpty { scheduleGroups.remove(at: i) }
                                break
                            }
                        }
                        self.loggedInUser?.schedules = scheduleGroups
                    }
                case .failure(let error):
                    print("Failed to delete past schedule: \(error.localizedDescription)")
                }
            }
        }
    }

    // MARK: - User & Schedule Deletion
    // Deletes a User record (admin only), then wipes their schedules as a follow-up
    func deleteUser(employee: Employee) {
        guard loggedInUser?.role == .storeDirector else {
            print("Only store directors can delete users.")
            return
        }

        let trimmedUsername = employee.name.trimmingCharacters(in: .whitespacesAndNewlines)

        CloudKitManager.shared.deleteUserRecord(username: trimmedUsername) { result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    print("User deleted: \(employee.name)")
                    if let index = self.loggedInUser?.employees.firstIndex(where: { $0.id == employee.id }) {
                        self.loggedInUser?.employees.remove(at: index)
                    }
                    self.deleteUserSchedules(username: employee.name)
                case .failure(let error):
                    print("Failed to delete user: \(error.localizedDescription)")
                }
            }
        }
    }

    // Deletes all BreakSchedule rows for a given username
    func deleteUserSchedules(username: String) {
        CloudKitManager.shared.deleteSchedules(forUsername: username) { result in
            switch result {
            case .success(let count):
                print("Deleted \(count) schedule(s) for user: \(username)")
            case .failure(let error):
                print("Failed to delete schedules for user \(username): \(error.localizedDescription)")
            }
        }
    }

    // MARK: - Utilities
    // Sorts employees by name ascending/descending and persists into users cache
    func sortEmployees(ascending: Bool = true) {
        guard let index = users.firstIndex(where: { $0.id == loggedInUser?.id }) else { return }
        users[index].employees.sort {
            ascending
                ? $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
                : $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedDescending
        }
        updateLoggedInUser(with: users[index])
        persistUsers()
    }

    // Clears any currently selected employees
    func resetSelectedEmployees() {
        selectedEmployees = []
    }

    // Sets notes for a specific EmployeeShift either by updating an existing one in `shifts` or appending a new copy
    func setNotes(for employeeShift: EmployeeShift, notes: NoteType) {
        if let index = shifts.firstIndex(where: { $0.id == employeeShift.id }) {
            shifts[index].notes = notes.rawValue
        } else {
            let newShift = EmployeeShift(
                id: employeeShift.id,
                employeeID: employeeShift.employeeID,
                name: employeeShift.name,
                role: employeeShift.role,
                department: employeeShift.department,
                shiftStart: employeeShift.shiftStart,
                shiftEnd: employeeShift.shiftEnd,
                notes: notes.rawValue,
                goals: employeeShift.goals
            )
            shifts.append(newShift)
        }
    }

    // Renders a simple PDF summary of schedules for a given date
    func generateSchedulePDF(for date: Date, shifts: [Schedule]) -> URL? {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short

        // PDF metadata
        let pdfMetaData = [
            kCGPDFContextCreator: "BreakScheduleApp",
            kCGPDFContextAuthor: "Emma Capirchio"
        ]

        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = pdfMetaData as [String: Any]

        // Letter size page
        let pageWidth: CGFloat = 612 // 8.5 inch
        let pageHeight: CGFloat = 792 // 11 inch
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)

        let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)

        let fileName = "Schedule-\(ISO8601DateFormatter().string(from: date)).pdf"
        let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)

        print("Generating PDF for \(shifts.count) shifts on \(date)")
        for shift in shifts {
            print("\(shift.name) — \(shift.shiftStart) to \(shift.shiftEnd)")
        }

        do {
            try renderer.writePDF(to: fileURL) { context in
                context.beginPage()

                let title = "Shift Schedule for \(formatter.string(from: date))"
                let titleAttributes: [NSAttributedString.Key: Any] = [
                    .font: UIFont.boldSystemFont(ofSize: 20)
                ]
                title.draw(at: CGPoint(x: 50, y: 50), withAttributes: titleAttributes)

                var yOffset: CGFloat = 100
                let bodyFont = UIFont.systemFont(ofSize: 14)

                for shift in shifts {
                    let start = formatter.string(from: shift.shiftStart)
                    let end = formatter.string(from: shift.shiftEnd)

                    let line = """
                    \(shift.name) – \(shift.shift)
                    Start: \(start) | End: \(end)
                    Breaks: 1st - \(shift.firstBreak), Lunch - \(shift.lunchBreak), 2nd - \(shift.secondBreak)
                    Goals: \(shift.goals)
                    Notes: \(shift.notes.rawValue)
                    """

                    line.draw(in: CGRect(x: 50, y: yOffset, width: pageWidth - 100, height: 80), withAttributes: [.font: bodyFont])
                    yOffset += 100
                }
            }

            return fileURL
        } catch {
            print("Failed to generate PDF: \(error)")
            return nil
        }
    }

    // MARK: - Subscriptions
    // Wires up listeners for CloudKit pushes and creates subscriptions for messages and swaps
    private func setUpCloudKitSubscriptions(for user: User) {
        // Observe CloudKit pushes from AppDelegate and refresh schedules
        if cloudKitPushObserver == nil {
            cloudKitPushObserver = NotificationCenter.default.addObserver(
                forName: .cloudKitSubscriptionNotificationReceived,
                object: nil,
                queue: .main
            ) { [weak self] _ in
                guard let self = self else { return }
                print("CloudKit push observed in ScheduleViewModel – refreshing schedules.")
                self.fetchCurrentSchedules()
            }
        }

        // Messages (visible notifications)
        self.subscribeToIncomingMessages(for: user)

        // Swap requests / status changes (visible notifications)
        CloudKitManager.shared.subscribeToSwapNotifications(for: user) { result in
            switch result {
            case .success:
                print("Swap subscriptions set up for \(user.username)")
            case .failure(let err):
                print("Swap subscription error: \(err.localizedDescription)")
            }
        }
    }
}

// MARK: - Extras / Helpers
extension ScheduleViewModel {
    // Combines a calendar date and a time-of-day into a single Date
    private func combine(date: Date, time: Date) -> Date {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day], from: date)
        let timeComponents = calendar.dateComponents([.hour, .minute, .second], from: time)

        var combined = DateComponents()
        combined.year = dateComponents.year
        combined.month = dateComponents.month
        combined.day = dateComponents.day
        combined.hour = timeComponents.hour
        combined.minute = timeComponents.minute
        combined.second = timeComponents.second

        return calendar.date(from: combined) ?? Date()
    }

    // Overwrites the current loggedInUser with an updated copy
    private func updateLoggedInUser(with updatedUser: User) {
        self.loggedInUser = updatedUser
    }

    // Simple persistence of the users array to UserDefaults
    func persistUsers() {
        do {
            let encodedData = try JSONEncoder().encode(users)
            UserDefaults.standard.set(encodedData, forKey: "users")
        } catch {
            print("Failed to encode users: \(error)")
        }
    }

    // MARK: - Subscribe To Incoming Messages (reused by setup helper)
    func subscribeToIncomingMessages(for user: User) {
        print("Attempting to subscribe for messages for: \(user.username)")
        CloudKitManager.shared.subscribeToNewMessages(for: user) { result in
            switch result {
            case .success:
                print("Subscribed to incoming messages for \(user.username)")
            case .failure(let error):
                print("Failed to subscribe: \(error.localizedDescription)")
            }
        }
    }

    // MARK: - Fetch Shifts by Date with Additional Role Filtering
    func fetchShiftsForDate(_ date: Date, completion: @escaping ([Schedule]) -> Void) {
        guard let user = loggedInUser else {
            print("No logged-in user found")
            completion([])
            return
        }

        CloudKitManager.shared.fetchSchedules(for: date, user: user) { result in
            switch result {
            case .success(let records):
                // Convert CKRecords -> Schedule models
                let schedules: [Schedule] = records.compactMap { record in
                    let employeeIDString = record["employeeID"] as? String ?? ""
                    let employeeID = UUID(uuidString: employeeIDString) ?? UUID()
                    // keep parsing other fields; only bail if those are really missing
                    guard let name = record["employeeName"] as? String,
                          let shiftStart = record["startTime"] as? Date,
                          let shiftEnd = record["endTime"] as? Date,
                          let firstBreak = record["firstBreak"] as? String,
                          let lunchBreak = record["lunchBreak"] as? String,
                          let secondBreak = record["secondBreak"] as? String,
                          let notesRaw = record["notes"] as? String,
                          let goals = record["goals"] as? String
                    else { return nil }


                    let shiftString = "\(shiftStart) - \(shiftEnd)"
                    let notes = NoteType(rawValue: notesRaw) ?? .general

                    return Schedule(
                        employeeID: employeeID,
                        name: name,
                        shift: shiftString,
                        firstBreak: firstBreak,
                        lunchBreak: lunchBreak,
                        secondBreak: secondBreak,
                        notes: notes,
                        goals: goals,
                        date: date,
                        shiftStart: shiftStart,
                        shiftEnd: shiftEnd
                    )
                }

                DispatchQueue.main.async {
                    print("Found \(schedules.count) schedule(s) for \(date)")
                    for schedule in schedules {
                        print("\(schedule.name) — \(schedule.shiftStart) to \(schedule.shiftEnd)")
                    }
                    completion(schedules)
                }

            case .failure(let error):
                print("Error fetching shifts: \(error.localizedDescription)")
                DispatchQueue.main.async { completion([]) }
            }
        }
    }

    // Clears the schedule
    func clearSchedule() { schedule.removeAll() }

    // Deletes one grouped schedules entry from the users cache and persists
    func deleteSchedule(at index: Int) {
        guard let loggedInUserIndex = users.firstIndex(where: { $0.id == loggedInUser?.id }) else { return }
        guard index >= 0 && index < users[loggedInUserIndex].schedules.count else { return }
        users[loggedInUserIndex].schedules.remove(at: index)
        updateLoggedInUser(with: users[loggedInUserIndex])
        persistUsers()
    }

    // Rebuilds selectedEmployees and schedule whenever loggedInUser changes
    private func updateUserData() {
        if let user = loggedInUser {
            selectedEmployees = user.employees.map { employee in
                if let existingShift = selectedEmployees.first(where: { $0.id == employee.id }) {
                    return existingShift
                } else if let storedShift = shifts.first(where: { $0.id == employee.id }) {
                    return storedShift
                } else {
                    return EmployeeShift(
                        id: employee.id,
                        employeeID: employee.id,
                        name: employee.name,
                        role: employee.role,
                        department: employee.department,
                        shiftStart: Date(),
                        shiftEnd: Date().addingTimeInterval(8*3600),
                        notes: NoteType.opu.rawValue
                    )
                }
            }
            schedule = user.schedules.flatMap { $0 }
        } else {
            selectedEmployees = []
            schedule = []
        }
    }
}
