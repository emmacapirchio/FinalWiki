//
//  ShiftSwapViewModel.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 4/23/25.
//
//  Purpose:
//  - View-model that loads shift swap requests from CloudKit,
//    lets the user accept/decline, and (on accept) performs the shift
//    swap by atomically updating both shift records.
//
//  Notes:
//  - Uses @MainActor to ensure UI-bound state updates happen on the main thread.
//  - `swapShifts` tolerates either "startTime/endTime" or legacy "shiftStart/shiftEnd" keys.
//  - Saves are atomic (.isAtomic = true) to avoid partial updates.
//

import Foundation
import CloudKit

@MainActor
class ShiftSwapViewModel: ObservableObject {
    @Published var shiftSwapRequests: [ShiftSwapRequest] = []
    @Published var showSwapSuccessAlert: Bool = false
    @Published var swapSuccessMessage: String = ""

    // Fetch all swap requests from CloudKit and publish into the list
    func loadSwapRequests() {
        CloudKitManager.shared.fetchShiftSwapRequests { result in
            Task { @MainActor in
                switch result {
                case .success(let requests):
                    self.shiftSwapRequests = requests
                case .failure(let error):
                    print("Failed to fetch shift swap requests: \(error.localizedDescription)")
                }
            }
        }
    }

    // Accept/decline a request. On accept, attempt to swap the two shifts in CloudKit.
    func respondToSwapRequest(_ request: ShiftSwapRequest, accept: Bool, currentUserId: CKRecord.ID) {
        let newStatus = accept ? "accepted" : "declined"

        CloudKitManager.shared.updateSwapRequestStatus(
            recordID: request.id,
            newStatus: newStatus
        ) { result in
            Task { @MainActor in
                switch result {
                case .success:
                    if accept {
                        self.swapShifts(for: request, currentUserId: currentUserId.recordName)
                    }
                    self.loadSwapRequests()
                case .failure(let error):
                    print("Error updating request: \(error.localizedDescription)")
                }
            }
        }
    }

    // Performs the swap of start/end/notes/goals between two BreakSchedule records
    func swapShifts(for request: ShiftSwapRequest, currentUserId: String) {
        let db = CloudKitManager.shared.publicDB

        // Require only the proposer’s shift id and target person’s identity.
        guard !request.proposerShiftID.isEmpty else {
            print("swapShifts aborted: missing proposerShiftID")
            return
        }
        let propID = CKRecord.ID(recordName: request.proposerShiftID)

        db.fetch(withRecordID: propID) { shiftRec, shiftErr in
            guard let shift = shiftRec, shiftErr == nil else {
                print("Proposer shift fetch failed: \(shiftErr?.localizedDescription ?? "unknown")")
                return
            }

            // Transfer ownership to the requested coworker
            shift["employeeName"] = request.requestedEmployeeName as CKRecordValue

            // Only update employeeID if it is a valid UUID
            if UUID(uuidString: request.requestedEmployeeID) != nil {
                shift["employeeID"] = request.requestedEmployeeID as CKRecordValue
            } else {
                print("swapShifts: requestedEmployeeID is not UUID; leaving employeeID unchanged")
            }

            // Audit fields
            shift["lastModifiedAt"] = Date() as CKRecordValue
            shift["lastModifiedBy"] = currentUserId as CKRecordValue

            // Also mark the ShiftSwapRequest approved
            let req = CKRecord(recordType: "ShiftSwapRequest", recordID: request.id)
            req["status"]     = "approved" as CKRecordValue
            req["approvedBy"] = currentUserId as CKRecordValue
            req["approvedAt"] = Date() as CKRecordValue

            // Save both atomically so UI stays consistent
            let op = CKModifyRecordsOperation(recordsToSave: [shift, req], recordIDsToDelete: nil)
            op.savePolicy = .ifServerRecordUnchanged
            op.isAtomic = true
            op.modifyRecordsResultBlock = { result in
                Task { @MainActor in
                    switch result {
                    case .success:
                        self.swapSuccessMessage = "Shift successfully transferred to \(request.requestedEmployeeName)."
                        self.showSwapSuccessAlert = true
                        self.loadSwapRequests()  // refresh list if you use one
                    case .failure(let error):
                        print("swapShifts save error: \(error.localizedDescription)")
                        self.loadSwapRequests()  // reconcile on conflict
                    }
                }
            }
            db.add(op)
        }
    }
}
