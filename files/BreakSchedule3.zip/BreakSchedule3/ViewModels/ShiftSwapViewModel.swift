//
//  ShiftSwapViewModel.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 4/23/25.
//
//  Purpose:
//  - Handles fetching, responding to, and executing shift swap requests.
//
//  Notes:
//   - Uses CloudKitManager for data operations.
//   - Presents simple success UI via published flags/message.
//



import Foundation
import CloudKit

class ShiftSwapViewModel: ObservableObject {
    // Live list of pending/handled swap requests for the UI
    @Published var shiftSwapRequests: [ShiftSwapRequest] = []
    // UI flags for user feedback after a successful swap
    @Published var showSwapSuccessAlert: Bool = false
    @Published var swapSuccessMessage: String = ""

    // Loads all swap requests from CloudKit and refreshes the UI
    func loadSwapRequests() {
        CloudKitManager.shared.fetchShiftSwapRequests { result in
            switch result {
            case .success(let requests):
                self.shiftSwapRequests = requests
            case .failure(let error):
                print("Failed to fetch shift swap requests: \(error.localizedDescription)")
            }
        }
    }
    
    // Accepts or declines a swap request; on accept, attempts to perform the swap
    func respondToSwapRequest(_ request: ShiftSwapRequest, accept: Bool, currentUserId: CKRecord.ID) {
        let newStatus: SwapStatus = accept ? .accepted : .declined

        CloudKitManager.shared.updateSwapRequestStatus(
            recordID: request.id,
            newStatus: accept ? "Accepted" : "Declined"
        ) { result in
            
            switch result {
            case .success:
                if accept {
                    // If accepted, proceed to swap the underlying shift details
                    self.swapShifts(for: request, currentUserId: currentUserId.recordName)
                }
                // Refresh the list after responding
                self.loadSwapRequests()
            case .failure(let error):
                print("Error updating request: \(error.localizedDescription)")
            }
        }
    }


    // Performs the swap by exchanging relevant fields between two BreakSchedule records
    func swapShifts(for request: ShiftSwapRequest, currentUserId: String) {
        let group = DispatchGroup()
        var proposerShiftRecord: CKRecord?
        var requestedShiftRecord: CKRecord?

        // Fetch proposer shift record
        group.enter()
        CloudKitManager.shared.fetchEmployeeShift(by: UUID(uuidString: request.proposerShiftID)!) { result in
            if case .success(let record) = result {
                proposerShiftRecord = record
            }
            group.leave()
        }

        // Fetch requested shift record
        group.enter()
        CloudKitManager.shared.fetchEmployeeShift(by: UUID(uuidString: request.requestedShiftID)!) { result in
            if case .success(let record) = result {
                requestedShiftRecord = record
            }
            group.leave()
        }

        // After both records are fetched, perform the swap
        group.notify(queue: .main) {
            guard var proposerShift = proposerShiftRecord, var requestedShift = requestedShiftRecord else {
                print("Failed to load both shifts.")
                return
            }

            // Cache proposer values before overwriting
            let proposerStart = proposerShift["shiftStart"] as? Date
            let proposerEnd = proposerShift["shiftEnd"] as? Date
            let proposerNotes = proposerShift["notes"] as? String
            let proposerGoals = proposerShift["goals"] as? String

            // Copy requested values → proposer
            proposerShift["shiftStart"] = requestedShift["shiftStart"]
            proposerShift["shiftEnd"] = requestedShift["shiftEnd"]
            proposerShift["notes"] = requestedShift["notes"]
            proposerShift["goals"] = requestedShift["goals"]

            // Copy cached proposer values → requested
            requestedShift["shiftStart"] = proposerStart as CKRecordValue?
            requestedShift["shiftEnd"] = proposerEnd as CKRecordValue?
            requestedShift["notes"] = proposerNotes as CKRecordValue?
            requestedShift["goals"] = proposerGoals as CKRecordValue?

            // Save both records together so the UI reflects the swap atomically from the user's perspective
            let saveOp = CKModifyRecordsOperation(recordsToSave: [proposerShift, requestedShift])
            saveOp.modifyRecordsCompletionBlock = { _, _, error in
                DispatchQueue.main.async {
                    if let error = error {
                        print("Swap save error: \(error.localizedDescription)")
                    } else {
                        self.swapSuccessMessage = "Shift swap completed successfully!"
                        self.showSwapSuccessAlert = true
                        print("Shift swap successful!")
                    }
                }
            }

            CKContainer.default().publicCloudDatabase.add(saveOp)
        }
    }


}
