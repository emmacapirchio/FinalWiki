//
//  SwapApprovalViewModel.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 5/16/25.
//
//  Purpose:
//  - Admin-facing VM to review, approve, or deny shift swap requests.
//
//  Notes:
//   - Approve path uses an atomic CloudKit operation that both approves the request
//     and exchanges shift ownership in a single transaction.
//   - Deny path only updates the request status; no schedule changes are made.
//   - Uses @MainActor to ensure published properties update safely for SwiftUI.
//

import Foundation
import CloudKit

@MainActor
final class SwapApprovalViewModel: ObservableObject {
    // Requests that are currently awaiting a decision
    @Published var pendingRequests: [ShiftSwapRequest] = []
    // Basic loading/error state for simple UI feedback
    @Published var isLoading = false
    @Published var errorMessage: String?

    // MARK: - Fetch pending
    // Pulls all swap requests and filters to "pending"/legacy "PendingApproval"
    func fetchPendingSwapRequests() {
        isLoading = true
        errorMessage = nil

        CloudKitManager.shared.fetchShiftSwapRequests { [weak self] result in
            Task { @MainActor in
                guard let self else { return }
                self.isLoading = false
                switch result {
                case .success(let all):
                    // accept "pending" and legacy "PendingApproval"
                    self.pendingRequests = all.filter {
                        let s = $0.status.lowercased()
                        return s == "pending" || s == "pendingapproval"
                    }
                    print("Fetched \(self.pendingRequests.count) pending swap requests")
                case .failure(let err):
                    self.errorMessage = err.localizedDescription
                    print("Failed to fetch swap requests: \(err.localizedDescription)")
                }
            }
        }
    }

    // MARK: - Approve (atomic: swaps both shifts + approves request together)
    // Calls CloudKitManager.approveSwapAndExchangeOwnership to update both BreakSchedule records
    // and the ShiftSwapRequest in a single atomic operation to avoid partial updates.
    func approveSwap(_ request: ShiftSwapRequest, approvedBy username: String) {
        errorMessage = nil

        CloudKitManager.shared.approveSwapAndExchangeOwnership(
            swapRequestID: request.id,
            approverUsername: username
        ) { [weak self] result in
            Task { @MainActor in
                guard let self else { return }
                switch result {
                case .success:
                    print("Swap request approved & ownership exchanged")
                    // Remove from local list since it is no longer pending
                    if let idx = self.pendingRequests.firstIndex(where: { $0.id == request.id }) {
                        self.pendingRequests.remove(at: idx)
                    }
                    // notify other views to refresh
                    NotificationCenter.default.post(name: .swapApproved, object: nil)

                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                    print("Error approving swap: \(error.localizedDescription)")
                }
            }
        }
    }

    // MARK: - Deny (no ownership change)
    // Updates the request to "denied" and removes it from the local pending list.
    func denySwap(_ request: ShiftSwapRequest, approvedBy username: String) {
        errorMessage = nil

        CloudKitManager.shared.updateSwapRequestStatus(
            recordID: request.id,
            newStatus: "declined",
            approvedBy: username
        ) { [weak self] result in
            Task { @MainActor in
                guard let self else { return }
                switch result {
                case .success:
                    print("Swap request denied")
                    if let idx = self.pendingRequests.firstIndex(where: { $0.id == request.id }) {
                        self.pendingRequests.remove(at: idx)
                    }
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                    print("Error denying swap: \(error.localizedDescription)")
                }
            }
        }
    }
}

// Used to notify interested views that an approval occurred and they should refresh.
extension Notification.Name {
    static let swapApproved = Notification.Name("swapApproved")
}
