//
//  SwapRequestFormViewModel.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 4/24/25.
//
//  Purpose:
//  - View-model for composing and sending a shift swap request.
//
//  Notes:
//   - Loads my shifts, coworkers, and the selected coworker’s shifts.
//   - Tracks current selections and presents simple success/failure alerts.
//   - Persists a ShiftSwapRequest in CloudKit with a normalized "pending" status.
//

import Foundation
import CloudKit

class SwapRequestFormViewModel: ObservableObject {
    // Data sources for the form
    @Published var myShifts: [EmployeeShift] = []
    @Published var coworkers: [Employee] = []
    @Published var coworkerShifts: [EmployeeShift] = []

    // Current selections made in the form
    @Published var selectedMyShiftId: CKRecord.ID?
    @Published var selectedCoworkerId: CKRecord.ID?
    @Published var selectedCoworkerShiftId: CKRecord.ID?

    // Simple user feedback
    @Published var showAlert = false
    @Published var alertMessage = ""

    // MARK: - Load current user's shifts + coworkers (+ first coworker shifts)
    func loadData(for user: User, preselecting shiftId: CKRecord.ID? = nil) {
        print("loadData() user=\(user.username), dept=\(user.department)")

        // Load MY shifts by username
        CloudKitManager.shared.fetchEmployeeShifts(forUsername: user.username) { result in
            switch result {
            case .success(let shifts):
                DispatchQueue.main.async {
                    self.myShifts = shifts
                    print("Loaded \(shifts.count) shifts for \(user.username)")

                    if let pre = shiftId, let match = shifts.first(where: { $0.id == pre }) {
                        self.selectedMyShiftId = match.id
                        print("Preselected my shift: \(match.id.recordName)")
                    } else if let first = shifts.first {
                        self.selectedMyShiftId = first.id
                        print("Auto-selected first my shift: \(first.id.recordName)")
                    }
                }
            case .failure(let err):
                print("Failed to load my shifts: \(err.localizedDescription)")
            }
        }

        // Load coworkers (excluding me), then auto-load the first coworker’s shifts
        CloudKitManager.shared.fetchEmployees(excluding: user.id) { result in
            switch result {
            case .success(let employees):
                DispatchQueue.main.async {
                    self.coworkers = employees
                    print("👥 Loaded \(employees.count) coworkers")

                    if let firstCoworker = employees.first {
                        self.selectedCoworkerId = firstCoworker.id
                        print("Auto-selected coworker: \(firstCoworker.name) [\(firstCoworker.id.recordName)]")
                        self.loadSelectedCoworkerShifts() // fetch their shifts by username
                    } else {
                        print("No coworkers available")
                    }
                }
            case .failure(let err):
                print("Failed to load coworkers: \(err.localizedDescription)")
            }
        }
    }

    // Call when user changes the selected coworker in the UI
    func loadSelectedCoworkerShifts() {
        guard let coworkerId = selectedCoworkerId,
              let coworker = coworkers.first(where: { $0.id == coworkerId }) else {
            self.coworkerShifts = []
            return
        }

        CloudKitManager.shared.fetchEmployeeShifts(forUsername: coworker.name) { result in
            switch result {
            case .success(let shifts):
                DispatchQueue.main.async {
                    self.coworkerShifts = shifts
                    print("Loaded \(shifts.count) shifts for coworker \(coworker.name)")
                    if let first = shifts.first {
                        self.selectedCoworkerShiftId = first.id
                        print("Auto-selected coworker shift: \(first.id.recordName)")
                    } else {
                        self.selectedCoworkerShiftId = nil
                    }
                }
            case .failure(let err):
                print("Failed to load coworker shifts: \(err.localizedDescription)")
            }
        }
    }

    // MARK: - Send request
    // Builds and saves a ShiftSwapRequest record to CloudKit.
    // Uses any employeeID carried in the selected shift; falls back to user/coworker ids if needed.
    func sendRequest(from user: User?) {
        guard let user = user else { return }
        guard let myShiftId = selectedMyShiftId else { return }
        guard let coworkerId = selectedCoworkerId,
              let coworker = coworkers.first(where: { $0.id == coworkerId }) else { return }

        // Prefer employeeID from the selected shift records (whatever is stored in BreakSchedule)
        let myShiftEmployeeIDString: String? = myShifts.first(where: { $0.id == myShiftId })?.employeeID.recordName
        let coworkerShiftEmployeeIDString: String? = selectedCoworkerShiftId.flatMap { id in
            coworkerShifts.first(where: { $0.id == id })?.employeeID.recordName
        }

        // Build the request
        let record = CKRecord(recordType: "ShiftSwapRequest")
        record["proposerEmployeeID"] = (myShiftEmployeeIDString ?? user.employeeID.uuidString) as CKRecordValue
        record["proposerEmployeeName"] = user.username as CKRecordValue
        record["proposerShiftID"] = myShiftId.recordName as CKRecordValue

        record["requestedEmployeeID"] = (coworkerShiftEmployeeIDString ?? coworker.id.recordName) as CKRecordValue
        record["requestedEmployeeName"] = coworker.name as CKRecordValue
        record["requestedShiftID"] = (selectedCoworkerShiftId?.recordName ?? "") as CKRecordValue

        // Normalize status to "pending" (your approval code handles "pending" or "PendingApproval")
        record["status"] = "pending" as CKRecordValue
        record["timestamp"] = Date() as CKRecordValue

        let db = CKContainer(identifier: "iCloud.com.ecapirchio.BreakSchedule").publicCloudDatabase
        db.save(record) { _, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.alertMessage = "Failed to send request: \(error.localizedDescription)"
                } else {
                    self.alertMessage = "Swap request sent!"
                }
                self.showAlert = true
            }
        }
    }
}
