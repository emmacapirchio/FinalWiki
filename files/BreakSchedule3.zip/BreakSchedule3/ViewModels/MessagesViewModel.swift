//
//  MessagesViewModel.swift
//  BreakSchedule3
//
//  Created by Emma Capirchio on 6/14/25.
//
//  Purpose:
//  - View-model for the in-app messaging feature.
//
//  Notes:
//  - Holds the current list of messages between two users and any text being composed.
//  - Uses CloudKitManager to fetch and send messages, keeping UI and database in sync.
//

import Foundation
import SwiftUI
import CloudKit

class MessagesViewModel: ObservableObject {
    // Published properties so SwiftUI views update automatically when changed.
    @Published var messages: [Message] = [] // All messages in the current conversation
    @Published var messageText: String = "" // Text currently being typed

    // Loads all messages exchanged between two users from CloudKit
    // and updates the `messages` array.
    func loadMessages(between user1: User, and user2: User) {
        CloudKitManager.shared.fetchMessages(between: user1, and: user2) { fetched in
            self.messages = fetched
        }
    }

    // Creates a new message and saves it to CloudKit.
    // On success, appends it to the local array and clears the input field.
    func sendMessage(from sender: User, to recipient: User) {
        let newMessage = Message(
            id: CKRecord.ID(recordName: UUID().uuidString),
            sender: sender,
            recipient: recipient,
            content: messageText,
            timestamp: Date()
        )

        CloudKitManager.shared.saveMessage(newMessage) { success in
            if success {
                DispatchQueue.main.async {
                    self.messages.append(newMessage)
                    self.messageText = ""
                }
            }
        }
    }
}
